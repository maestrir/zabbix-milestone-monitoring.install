<#
.SYNOPSIS
  READ-ONLY diagnosis: can this video server be monitored by the Zabbix package (MilestoneMonitor)?
  Installs nothing, changes nothing in Milestone or Windows. Writes only its report next to this script.

.DESCRIPTION
  Run as Administrator:
      powershell -ExecutionPolicy Bypass -File .\Test-MilestoneCompat.ps1
  Milestone access is tested automatically with the Windows user running the diagnosis (e.g. Administrator).
  Optional: -User <basic user> also tests an XProtect basic user (password asked, used only in memory).

  Checks: Windows/PowerShell versions (Zabbix Agent 2 needs Server 2016+), Milestone components and versions,
  services, Management Server endpoints (well-known URIs, IDP, REST API, SOAP), login and recorder status,
  media database folder names, Milestone logs, Smart Client export settings, Mobile Server port,
  MilestonePSTools, connection to the Zabbix server on TCP 10051.
  Report: Diagnosi-Milestone-<computer>-<date>.txt in the script folder (no passwords, no tokens).
#>
[CmdletBinding()]
param(
    [string] $MgmUrl = "http://$env:COMPUTERNAME",
    [string] $ZabbixServer = 'controllomilestone.mysecuritycamera.org',
    [string] $User,
    [switch] $NoLogin,
    [switch] $PasswordFromStdin,      # tests only: read the password from standard input
    [ValidateSet('auto', 'rest', 'legacy')] [string] $CollectMode = 'auto'   # tests only: force the collection mode
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
$report = New-Object System.Collections.Generic.List[string]
$OUT = Join-Path $PSScriptRoot ("Diagnosi-Milestone-{0}-{1:yyyyMMdd-HHmm}.txt" -f $env:COMPUTERNAME, (Get-Date))

function Say([string]$status, [string]$text) {
    $line = "[{0}] {1}" -f $status, $text
    $color = switch ($status) { 'OK' { 'Green' } 'NO' { 'Red' } 'ATT' { 'Yellow' } default { 'Gray' } }
    Write-Host $line -ForegroundColor $color
    $report.Add($line)
}
function Title([string]$t) { Write-Host ''; Write-Host "== $t ==" -ForegroundColor Cyan; $report.Add(''); $report.Add("== $t ==") }
function Http([string]$url, [string]$method = 'GET', [string]$body = $null, [hashtable]$headers = @{}, [string]$ct = $null) {
    $p = @{ Uri = $url; Method = $method; UseBasicParsing = $true; Headers = $headers; TimeoutSec = 15 }
    if ($body) { $p.Body = [Text.Encoding]::UTF8.GetBytes($body) }
    if ($ct) { $p.ContentType = $ct }
    try { $r = Invoke-WebRequest @p; return @{ code = [int]$r.StatusCode; content = $r.Content } }
    catch [Net.WebException] {
        if ($_.Exception.Response) {
            $txt = ''
            try { $txt = (New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())).ReadToEnd() } catch { }
            return @{ code = [int]$_.Exception.Response.StatusCode; content = $txt }
        }
        return @{ code = 0; content = $_.Exception.Message }
    }
    catch { return @{ code = 0; content = $_.Exception.Message } }
}

# ------------------------------------------------------------------ Windows
Title 'Windows'
$os = Get-CimInstance Win32_OperatingSystem
Say 'INFO' ("{0} (build {1})" -f $os.Caption, $os.BuildNumber)
if ([int]$os.BuildNumber -ge 14393) { Say 'OK' 'Zabbix Agent 2 (8.0) installabile: Windows 10 / Server 2016 o successivi' }
else { Say 'NO' 'Windows piu vecchio di Server 2016: Zabbix Agent 2 non funziona, serve l''agent classico' }
Say 'INFO' ("PowerShell {0}" -f $PSVersionTable.PSVersion)
if ($PSVersionTable.PSVersion.Major -lt 5) { Say 'NO' 'Serve PowerShell 5.1' } else { Say 'OK' 'PowerShell 5.1 o superiore' }

# ------------------------------------------------------------------ Milestone components
Title 'Componenti Milestone installati'
$apps = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -match 'Milestone|XProtect' } | Sort-Object DisplayName -Unique
foreach ($a in $apps) { Say 'INFO' ("{0}  {1}" -f $a.DisplayName, $a.DisplayVersion) }
if (-not $apps) { Say 'ATT' 'Nessun componente Milestone trovato nel registro' }
Title 'Servizi Milestone'
Get-Service | Where-Object { $_.DisplayName -match 'Milestone|XProtect' } | Sort-Object DisplayName | ForEach-Object {
    Say $(if ($_.Status -eq 'Running') { 'OK' } else { 'ATT' }) ("{0}: {1}" -f $_.DisplayName, $_.Status)
}

# ------------------------------------------------------------------ Management Server endpoints
Title "Management Server ($MgmUrl)"
$base = $MgmUrl.TrimEnd('/')
$wk = Http "$base/api/.well-known/uris"
$uris = $null
if ($wk.code -eq 200) {
    $uris = $wk.content | ConvertFrom-Json
    Say 'OK' ("/api/.well-known/uris presente (versione {0})" -f $uris.ProductVersion)
    Say 'INFO' ("IDP: {0}   API Gateway: {1}" -f $uris.IdentityProvider, ($uris.ApiGateways -join ', '))
} else { Say 'NO' ("/api/.well-known/uris non disponibile (HTTP {0}): versione senza API Gateway" -f $wk.code) }

$idp = if ($uris -and $uris.IdentityProvider) { $uris.IdentityProvider.TrimEnd('/') } else { "$base/IDP" }
$oc = Http "$idp/.well-known/openid-configuration"
if ($oc.code -eq 200) { Say 'OK' "IDP risponde ($idp)" } else { Say 'NO' ("IDP non risponde su $idp (HTTP {0})" -f $oc.code) }

$api = if ($uris -and $uris.ApiGateways) { "$($uris.ApiGateways[0])".TrimEnd('/') } else { "$base/API" }
$rest = Http "$api/rest/v1/sites"
switch ($rest.code) {
    401 { Say 'OK' "API REST presente ($api/rest/v1: chiede il login)" }
    200 { Say 'OK' "API REST presente ($api/rest/v1)" }
    default { Say 'NO' ("API REST non disponibile (HTTP {0}): servira' la modalita' compatibile" -f $rest.code) }
}
foreach ($svc in 'ServerCommandServiceOAuth.svc', 'ServerCommandService.svc', 'ConfigurationApiService.svc') {
    $r = Http "$base/ManagementServer/$svc"
    $ok = $r.code -in 200, 400, 401, 405, 415
    Say $(if ($ok) { 'OK' } else { 'ATT' }) ("SOAP {0}: HTTP {1}" -f $svc, $r.code)
}

# ------------------------------------------------------------------ login test (optional)
Title 'Prova di un utente base Milestone (solo con -User)'
$xpToken = $null
if (-not $NoLogin) {
    # basic user test only when asked (-User): the normal access is Windows, tested automatically below
    if ($User) {
        if ($PasswordFromStdin) { $pw = [Console]::In.ReadLine() }
        else {
            $s = Read-Host "Password di $User (non viene salvata)" -AsSecureString
            $pw = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
        }
        $form = 'grant_type=password&client_id=GrantValidatorClient&username=' + [Uri]::EscapeDataString($User) +
                '&password=' + [Uri]::EscapeDataString($pw)
        $pw = $null
        $tok = Http "$idp/connect/token" 'POST' $form @{} 'application/x-www-form-urlencoded'
        if ($tok.code -eq 200) {
            $oauth = ($tok.content | ConvertFrom-Json).access_token
            Say 'OK' 'Token IDP ottenuto (utente base)'
            $mgm = if ($uris -and $uris.SecureManagementServer) { $uris.SecureManagementServer } elseif ($uris) { $uris.UnsecureManagementServer } else { "$base/" }
            $login = "<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'><s:Body><Login xmlns='http://videoos.net/2/XProtectCSServerCommand'>" +
                     "<instanceId>6719498d-5848-404a-96cd-ba3589a9b67f</instanceId><currentToken /></Login></s:Body></s:Envelope>"
            $l = Http "${mgm}ManagementServer/ServerCommandServiceOauth.svc" 'POST' $login @{ Authorization = "Bearer $oauth"
                    SOAPAction = 'http://videoos.net/2/XProtectCSServerCommand/IServerCommandService/Login' } 'text/xml'
            if ($l.code -eq 200 -and $l.content -match '<Token>([^<]+)</Token>') {
                $xpToken = $Matches[1]
                Say 'OK' 'Login SOAP (OAuth) riuscito: token XProtect ottenuto'
            } else { Say 'NO' ("Login SOAP OAuth non riuscito (HTTP {0})" -f $l.code) }
            if ($rest.code -in 200, 401) {
                $s = Http "$api/rest/v1/cameras" 'GET' $null @{ Authorization = "Bearer $oauth" }
                if ($s.code -eq 200) { Say 'OK' ("API REST: elenco telecamere letto ({0} telecamere)" -f @(($s.content | ConvertFrom-Json).array).Count) }
                else { Say 'NO' ("API REST: elenco telecamere non letto (HTTP {0})" -f $s.code) }
            }
        } else {
            $why = ''
            if ($tok.content -match '"error"\s*:\s*"([^"]+)"') { $why = $Matches[1] }
            if ($tok.content -match '"error_description"\s*:\s*"([^"]+)"') { $why += ' - ' + $Matches[1] }
            Say 'NO' ("Token IDP non ottenuto (HTTP {0} {1}): utente/password sbagliati, utente non 'base' o versione" -f $tok.code, $why)
        }
    } else { Say 'INFO' 'Prova di login saltata' }
}

# ------------------------------------------------------------------ Windows access of the current user
# The Zabbix agent will run as a Windows user that is in a Milestone role (e.g. .\Administrator):
# run this diagnosis as that user to test exactly that access.
Title ("Accesso Windows a Milestone come {0}" -f [Security.Principal.WindowsIdentity]::GetCurrent().Name)
try {
    $r = Invoke-WebRequest -UseBasicParsing -UseDefaultCredentials -Method Post -Uri "$idp/connect/token" `
         -Body 'grant_type=windows_auth&client_id=winauthclient' -ContentType 'application/x-www-form-urlencoded' -TimeoutSec 20
    $wt = ($r.Content | ConvertFrom-Json).access_token
    if ($rest.code -in 200, 401) {
        $c = Http "$api/rest/v1/cameras" 'GET' $null @{ Authorization = "Bearer $wt" }
        if ($c.code -eq 200) { Say 'OK' ("Accesso Windows funziona: {0} telecamere lette. L'agent puo' girare con questo utente." -f @(($c.content | ConvertFrom-Json).array).Count) }
        elseif ($c.code -eq 403) { Say 'ATT' 'Questo utente Windows entra ma non e'' in nessun ruolo Milestone: aggiungerlo a un ruolo' }
        else { Say 'NO' ("Accesso Windows: lettura non riuscita (HTTP {0})" -f $c.code) }
    } else { Say 'INFO' 'Token Windows ottenuto (la lettura REST non e'' disponibile su questa versione)' }
    $wt = $null
} catch { Say 'NO' ("Accesso Windows non riuscito: {0}" -f $_.Exception.Message) }

# ------------------------------------------------------------------ recorder status (SOAP RecorderStatus2)
Title 'Stato recorder (RecorderStatus2)'
$recUrl = 'http://localhost:7563/recorderstatusservice/recorderstatusservice2.asmx'
$w = Http "${recUrl}?WSDL"
if ($w.code -eq 200) { Say 'OK' "RecorderStatus2 presente su questo server ($recUrl)" } else { Say 'ATT' ("RecorderStatus2 non trovato su localhost:7563 (HTTP {0}): recorder su un altro server o porta diversa" -f $w.code) }
if ($xpToken -and $w.code -eq 200) {
    $b = "<soap:Envelope xmlns:soap='http://www.w3.org/2003/05/soap-envelope' xmlns:xpr='http://videoos.net/2/XProtectCSRecorderStatus2'><soap:Header/><soap:Body>" +
         "<xpr:GetRecorderStatus><xpr:token>$xpToken</xpr:token></xpr:GetRecorderStatus></soap:Body></soap:Envelope>"
    $r = Http $recUrl 'POST' $b @{} "application/soap+xml;charset=UTF-8;action='http://videoos.net/2/XProtectCSRecorderStatus2/GetRecorderStatus'"
    if ($r.code -eq 200 -and $r.content -match 'ConnectionState>([^<]+)<') { Say 'OK' "Stato recorder letto: $($Matches[1])" }
    else { Say 'NO' ("Stato recorder non letto (HTTP {0})" -f $r.code) }
}
$xpToken = $null

# ------------------------------------------------------------------ media database
Title 'Database video (solo nomi delle cartelle)'
$re = '^[0-9a-fA-F-]{36}_[A-Za-z]+_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$'
$found = $false
foreach ($d in (Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Free -ne $null })) {
    foreach ($m in (Get-ChildItem -Path $d.Root -Directory -Filter 'MediaDatabase' -ErrorAction SilentlyContinue)) {
        $found = $true
        $tables = @(Get-ChildItem -LiteralPath $m.FullName -Directory -Depth 1 -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $re })
        if ($tables.Count -gt 0) { Say 'OK' ("{0}: {1} cartelle orarie nel formato atteso (es. {2})" -f $m.FullName, $tables.Count, $tables[0].Name) }
        else { Say 'ATT' ("{0}: nessuna cartella nel formato <GUID>_LOCAL_<data>: la conservazione reale va adattata" -f $m.FullName) }
    }
}
if (-not $found) { Say 'ATT' 'Nessuna cartella MediaDatabase alla radice dei dischi (storage in un percorso diverso o su NAS)' }

# ------------------------------------------------------------------ logs
Title 'Log Milestone'
$pd = 'C:\ProgramData\Milestone'
if (Test-Path $pd) {
    Get-ChildItem $pd -Directory | ForEach-Object { Say 'INFO' ("Cartella log: {0}" -f $_.Name) }
    $db = @(Get-ChildItem "$pd\XProtect Recording Server\Logs\Database_*.log" -ErrorAction SilentlyContinue)
    Say $(if ($db.Count) { 'OK' } else { 'ATT' }) ("Log del database (Database_*.log): {0} file" -f $db.Count)
} else { Say 'ATT' "Cartella $pd non trovata" }

# ------------------------------------------------------------------ Smart Client exports
Title 'Smart Client (esportazioni)'
$us = @(Get-ChildItem 'C:\Users\*\AppData\Roaming\Milestone\Smart Client\UserSettings*.xml' -Force -ErrorAction SilentlyContinue)
if ($us.Count -eq 0) { Say 'ATT' 'Nessuna impostazione dello Smart Client trovata (mai usato su questo server?)' }
foreach ($f in $us) {
    $m = Select-String -Path $f.FullName -Pattern 'ExportPath="([^"]*)"' | Select-Object -First 1
    if ($m) {
        $ep = $m.Matches[0].Groups[1].Value
        Say 'OK' ("{0}: cartella esportazioni {1}" -f $f.Name, $ep)
        if ($ep -match '^([A-Za-z]):') {
            $letter = $Matches[1].ToUpper()
            $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='${letter}:'" -ErrorAction SilentlyContinue
            $types = @{ 2 = 'rimovibile'; 3 = 'disco locale'; 4 = 'unita'' di rete'; 5 = 'CD/DVD' }
            if ($disk) { Say 'INFO' ("  {0}: {1} {2}" -f $letter, $types[[int]$disk.DriveType], $disk.ProviderName) }
            else { Say 'ATT' ("  {0}: non presente in questa sessione" -f $letter) }
            $remote = (Get-ItemProperty "HKCU:\Network\$letter" -Name RemotePath -ErrorAction SilentlyContinue).RemotePath
            if ($remote) { Say 'OK' ("  {0}: mappatura salvata verso {1} (l'agent usera' questo percorso)" -f $letter, $remote) }
            elseif ($disk -and [int]$disk.DriveType -eq 4) { Say 'ATT' ("  {0}: unita' di rete NON salvata come permanente: l'agent non la vedra' (rimapparla con 'Riconnetti all'accesso')" -f $letter) }
        }
    }
    else { Say 'ATT' ("{0}: ExportPath non trovato" -f $f.FullName) }
}

# ------------------------------------------------------------------ Mobile Server
Title 'Mobile Server'
$mc = 'C:\Program Files\Milestone\XProtect Mobile Server\VideoOS.MobileServer.Service.exe.config'
if (Test-Path $mc) {
    try { [xml]$x = Get-Content $mc -Raw; $n = $x.SelectSingleNode("//HttpMetaChannel/Address/add[@key='Port']")
          if ($n) { Say 'OK' ("Porta HTTP del Mobile Server: {0}" -f $n.value) } else { Say 'ATT' 'Porta del Mobile Server non trovata nella configurazione' } }
    catch { Say 'ATT' 'Configurazione del Mobile Server non leggibile' }
} else { Say 'INFO' 'Mobile Server non installato in questo percorso' }

# ------------------------------------------------------------------ full test of the collection (no installation)
# Runs milestone_collect.ps1 of the package exactly as the agent will (mode chosen like the installer, Windows access
# of the user running this diagnosis), with configuration and cache in a temporary folder that is deleted at the end.
$collector = Join-Path $PSScriptRoot 'milestone_collect.ps1'
$mode = if ($CollectMode -ne 'auto') { $CollectMode } elseif ($wk.code -eq 200) { 'rest' } else { 'legacy' }
Title ("Prova completa della raccolta (modalita' {0}, come {1})" -f $mode, [Security.Principal.WindowsIdentity]::GetCurrent().Name)
if (-not (Test-Path $collector)) { Say 'INFO' 'milestone_collect.ps1 non e'' nella cartella: prova saltata' }
elseif ($mode -eq 'legacy' -and -not (Get-Module -ListAvailable -Name MilestonePSTools)) { Say 'NO' 'Modalita'' compatibile: serve MilestonePSTools (Install-Module MilestonePSTools)' }
else {
    $tmp = Join-Path $env:TEMP ("zbx-collect-test-" + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tmp | Out-Null
    @{ mgm_url = $MgmUrl; api = $mode; auth = 'windows'; user = ''; mob_port = 0 } | ConvertTo-Json | Set-Content "$tmp\config.json" -Encoding ASCII
    $env:ZBXMS_DIR = $tmp; $env:ZBXMS_CONFIG = "$tmp\config.json"
    function Run-Collect([string]$m) {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $o = "$(& powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File $collector $m 2>&1)"
        @{ out = $o; sec = [math]::Round($sw.Elapsed.TotalSeconds, 1) }
    }
    function Short([string]$t) { $t.Substring(0, [Math]::Min(300, $t.Length)) }
    $r = Run-Collect 'info'
    if ($r.out -notlike '{*') { Say 'NO' ("Elenchi ({0} s): {1}" -f $r.sec, (Short $r.out)) }
    else {
        $i = $r.out | ConvertFrom-Json
        $active = @($i.Hw.Cam | Where-Object { $_.enabled -and $_.hwEnabled -ne $false }).Count
        Say 'OK' ("Elenchi ({0} s): {1} {2}, {3} recorder, {4} telecamere ({5} attive), {6} apparati" -f $r.sec,
            $i.Product.Name, $i.Product.Version, @($i.Srv.Rec).Count, @($i.Hw.Cam).Count, $active, @($i.Hw.Dev).Count)
        Say 'INFO' ("Telecamere con nome breve o descrizione compilati: {0}" -f @($i.Hw.Cam | Where-Object { $_.shortName -or $_.description }).Count)
        $r = Run-Collect 'status'
        if ($r.out -like '{*') {
            $s = $r.out | ConvertFrom-Json
            $recState = ($s.rec.PSObject.Properties | ForEach-Object { $_.Value }) -join ', '
            $recCount = @($s.cam | Where-Object { $_.Recording -eq 'true' }).Count
            $novideo = @($s.cam | Where-Object { $_.Enabled -eq 'true' -and ($_.ErrorNoConnection -eq 'true' -or $_.Started -eq 'false') }).Count
            Say 'OK' ("Stato ({0} s): recorder {1}; {2} telecamere lette, {3} in registrazione, {4} attive senza video; {5} storage" -f
                $r.sec, $recState, @($s.cam).Count, $recCount, $novideo, @($s.storage).Count)
        } else { Say 'NO' ("Stato ({0} s): {1}" -f $r.sec, (Short $r.out)) }
        $r = Run-Collect 'license'
        if ($r.out -like '{*') { Say 'OK' ("Licenze ({0} s): {1}" -f $r.sec, ($r.out | ConvertFrom-Json).summary) }
        else { Say 'NO' ("Licenze ({0} s): {1}" -f $r.sec, (Short $r.out)) }
        # the full folder scan now (in normal use it runs in the background), then the item reads its result
        $b = Run-Collect 'retention-build'
        $r = Run-Collect 'retention'; $r.sec = $b.sec
        if ($b.out -match '^ERROR') { $r.out = $b.out }
        if ($r.out -like '{*') {
            $cams = @(($r.out | ConvertFrom-Json).cam.PSObject.Properties | ForEach-Object { $_.Value })
            if ($cams.Count) {
                $min = ($cams | ForEach-Object { if ($_.cfg_days -gt 0) { $_.days / $_.cfg_days * 100 } else { 100 } } | Measure-Object -Minimum).Minimum
                Say 'OK' ("Conservazione ({0} s): {1} telecamere, la piu' bassa al {2:N0}% della configurata" -f $r.sec, $cams.Count, $min)
            } else { Say 'ATT' ("Conservazione ({0} s): nessuna cartella di registrazione trovata nei percorsi degli storage" -f $r.sec) }
        } else { Say 'NO' ("Conservazione ({0} s): {1}" -f $r.sec, (Short $r.out)) }
    }
    Remove-Item Env:ZBXMS_DIR, Env:ZBXMS_CONFIG -ErrorAction SilentlyContinue
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}

# ------------------------------------------------------------------ MilestonePSTools
Title 'MilestonePSTools'
$mod = Get-Module -ListAvailable -Name MilestonePSTools | Sort-Object Version -Descending | Select-Object -First 1
if ($mod) {
    Say 'OK' ("MilestonePSTools {0} installato (utile per la modalita' compatibile)" -f $mod.Version)
    try {
        Import-Module MilestonePSTools -ErrorAction Stop
        $need = [ordered]@{ 'Connect-Vms' = @('Connect-Vms'); 'ManagementServer' = @('Get-VmsManagementServer', 'Get-ManagementServer')
            'RecordingServer' = @('Get-VmsRecordingServer', 'Get-RecordingServer'); 'Storage' = @('Get-VmsStorage')
            'ArchiveStorage' = @('Get-VmsArchiveStorage', 'Get-ArchiveStorage'); 'Hardware' = @('Get-VmsHardware', 'Get-Hardware')
            'Camera' = @('Get-VmsCamera'); 'Token' = @('Get-VmsToken', 'Get-Token'); 'LicenseInfo' = @('Get-VmsLicenseInfo', 'Get-LicenseInfo')
            'LicenseDetails' = @('Get-VmsLicenseDetails', 'Get-LicenseDetails'); 'LicenseOverview' = @('Get-VmsLicenseOverview', 'Get-LicenseOverview')
            'LicensedProducts' = @('Get-VmsLicensedProducts', 'Get-LicensedProducts') }
        $ok = @(); $miss = @()
        foreach ($k in $need.Keys) {
            $f = $need[$k] | Where-Object { Get-Command $_ -ErrorAction SilentlyContinue } | Select-Object -First 1
            if ($f) { $ok += $f } else { $miss += ($need[$k] -join '/') }
        }
        Say 'INFO' ("Comandi PSTools trovati: {0}" -f ($ok -join ', '))
        if ($miss) { Say 'NO' ("Comandi PSTools mancanti: {0}" -f ($miss -join ', ')) }
        # license rows as this PSTools version returns them (the legacy mode looks for the device license)
        $lo = ($need['LicenseOverview'] | Where-Object { Get-Command $_ -ErrorAction SilentlyContinue } | Select-Object -First 1)
        $ld = ($need['LicenseDetails'] | Where-Object { Get-Command $_ -ErrorAction SilentlyContinue } | Select-Object -First 1)
        if ($lo -and $ld) {
            try {
                Connect-Vms -ServerAddress $MgmUrl -AcceptEula -ErrorAction Stop | Out-Null
                foreach ($row in @(& $lo)) { Say 'INFO' ("  Licenze (overview): tipo='{0}' plugin={1} attivate='{2}'" -f $row.LicenseType, $row.PluginId, $row.Activated) }
                foreach ($row in @(& $ld)) { Say 'INFO' ("  Licenze (dettagli): tipo='{0}' attivate={1} grazia={2} scadute={3} proprieta': {4}" -f $row.LicenseType, $row.Activated, $row.InGrace, $row.GraceExpired, (($row.PSObject.Properties.Name | Select-Object -First 8) -join ',')) }
                Disconnect-Vms -ErrorAction SilentlyContinue
            } catch { Say 'ATT' ("Lettura licenze con PSTools non riuscita: {0}" -f $_.Exception.Message) }
        }
    } catch { Say 'ATT' ("MilestonePSTools non caricabile: {0}" -f $_.Exception.Message) }
}
else { Say 'INFO' 'MilestonePSTools non installato' }

# ------------------------------------------------------------------ Zabbix
Title "Collegamento verso Zabbix ($ZabbixServer porta 10051)"
$t = Test-NetConnection -ComputerName $ZabbixServer -Port 10051 -WarningAction SilentlyContinue
if ($t.TcpTestSucceeded) { Say 'OK' ("{0} raggiungibile ({1})" -f $ZabbixServer, $t.RemoteAddress) }
else { Say 'NO' ("{0} non raggiungibile sulla porta 10051 (DNS, internet o inoltro sul router)" -f $ZabbixServer) }

$report | Set-Content -Path $OUT -Encoding UTF8
Write-Host ''
Write-Host "Rapporto salvato in: $OUT" -ForegroundColor Green
Write-Host 'Mandalo a chi segue il progetto Zabbix: non contiene password.' -ForegroundColor Green
