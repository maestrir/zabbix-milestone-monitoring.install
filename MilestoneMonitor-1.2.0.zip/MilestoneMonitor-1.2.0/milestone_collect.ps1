<#
  milestone_collect.ps1 - reads Milestone XProtect data LOCALLY on the video server, for the Zabbix agent
  (active checks only: nothing has to be reachable from the Zabbix server).

  It replaces the "script" items of the community template "Milestone XProtect" (lestoilfante, GPLv3), which run
  on the Zabbix server and need direct access to the Management/Recording servers. The output keeps the same
  shapes, so the discovery rules and item prototypes of the template keep working (template "Milestone XProtect (agent)").

  Usage (UserParameters, see milestone_monitor.conf):
    milestone_collect.ps1 info      -> mxp.info     discovery JSON (same structure as the community script, no tokens)
    milestone_collect.ps1 status    -> mxp.status   recorders, cameras, storages, archives, services, mobile servers
    milestone_collect.ps1 license   -> mxp.license  licenses + storage configuration (template "Milestone Riepilogo")
    milestone_collect.ps1 retention -> mxp.retention  oldest recording per camera (reads retention.json; the folder
                                                      scan runs in the background: mode retention-build)
    milestone_collect.ps1 nas       -> mxp.nas      NAS in the LAN: shares space, SMB, SNMP health (template "NAS via server video")
    milestone_collect.ps1 vpn       -> mxp.vpn      OpenVPN tunnels (.ovpn files), up/down, clients connected, services
    milestone_collect.ps1 services  -> mxp.services Windows services with automatic start that are not running
    milestone_collect.ps1 deletions -> mxp.deletions recordings deleted in the last 24 h and why (Database logs)

  Configuration (written by the installer):
    C:\ProgramData\zbx-milestone\config.json      {"mgm_url": "http://server", "auth": "windows"|"basic", "user": "...", "mob_port": 0}
      auth "windows" (default): Windows authentication of the agent account NT AUTHORITY\SYSTEM (add it to a
                                Milestone role); no password anywhere.
      auth "basic": XProtect basic user, password in
    C:\ProgramData\zbx-milestone\credential.bin   encrypted with DPAPI (LocalMachine scope)
  Cache (no secrets in clear): info.json (last discovery), token.bin (tokens, DPAPI)
#>
param([ValidateSet('info', 'status', 'license', 'retention', 'retention-build', 'nas', 'vpn', 'services', 'deletions')] [string] $Mode = 'status',
      [string] $DataDir = '')

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$WarningPreference = 'SilentlyContinue'      # module warnings would end up in the output and break the JSON
$InformationPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Security

# ZBXMS_DIR: other data folder (tests only, e.g. the diagnosis: nothing is written in ProgramData)
$DIR = if ($DataDir) { $DataDir } elseif ($env:ZBXMS_DIR) { $env:ZBXMS_DIR } else { Join-Path $env:ProgramData 'zbx-milestone' }
$INSTANCE_ID = '6719498d-5848-404a-96cd-ba3589a9b67f'   # same integration id as the community template

# Local endpoints only: accept the Milestone self-signed certificates for this process.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

# ---------------------------------------------------------------- helpers
function Read-Protected([string]$path) {
    $bytes = [IO.File]::ReadAllBytes($path)
    $plain = [Security.Cryptography.ProtectedData]::Unprotect($bytes, $null, 'LocalMachine')
    [Text.Encoding]::UTF8.GetString($plain)
}

function Write-Protected([string]$path, [string]$text) {
    $enc = [Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($text), $null, 'LocalMachine')
    [IO.File]::WriteAllBytes($path, $enc)
}

function To-Unix([datetime]$t) { [int64]([DateTimeOffset]$t.ToUniversalTime()).ToUnixTimeSeconds() }

function Invoke-Http([string]$url, [string]$method = 'GET', [string]$body = $null, [hashtable]$headers = @{},
                     [string]$contentType = $null, [int]$timeout = 30, [switch]$windowsAuth) {
    $p = @{ Uri = $url; Method = $method; UseBasicParsing = $true; Headers = $headers; TimeoutSec = $timeout }
    if ($windowsAuth) { $p.UseDefaultCredentials = $true }   # the account running the script (SYSTEM for the agent)
    if ($body) { $p.Body = [Text.Encoding]::UTF8.GetBytes($body) }
    if ($contentType) { $p.ContentType = $contentType }
    # remembered for the error line of main: which call failed (no query string; secrets go in body/headers only)
    $script:LastHttp = "$method " + ($url -replace '\?.*$', '')
    Invoke-WebRequest @p
}

function Get-Json([string]$url, [string]$token) {
    $r = Invoke-Http $url -headers @{ Authorization = "Bearer $token"; Accept = 'application/json' }
    ($r.Content | ConvertFrom-Json)
}

function Get-StatusCode([string]$url) {
    try { return [int](Invoke-Http $url -timeout 5).StatusCode }
    catch [Net.WebException] {
        if ($_.Exception.Response) { return [int]$_.Exception.Response.StatusCode }
        return 0
    }
    catch { return 0 }
}

# XML element -> flat object of its simple child elements (strings, like Zabbix XML.toJson does for text nodes)
function ConvertFrom-XmlElement($el) {
    $o = [ordered]@{}
    foreach ($c in $el.ChildNodes) {
        if ($c.NodeType -ne 'Element') { continue }
        $hasElements = $false
        foreach ($cc in $c.ChildNodes) { if ($cc.NodeType -eq 'Element') { $hasElements = $true; break } }
        if (-not $hasElements) { $o[$c.LocalName] = $c.InnerText }
    }
    $o
}

# all elements below $xml that have a child element named $idName
function Find-Records($xml, [string]$idName) {
    @($xml.SelectNodes("//*[*[local-name()='$idName']]") | ForEach-Object { ConvertFrom-XmlElement $_ })
}

# ---------------------------------------------------------------- authentication
function Get-Config {
    # ZBXMS_CONFIG: other configuration file (tests only)
    $file = if ($env:ZBXMS_CONFIG) { $env:ZBXMS_CONFIG } else { Join-Path $DIR 'config.json' }
    $cfg = Get-Content $file -Raw | ConvertFrom-Json
    if (-not $cfg.mgm_url) { throw 'config.json: mgm_url missing' }
    $cfg
}

function Get-Uris($cfg) {
    $base = $cfg.mgm_url.TrimEnd('/')
    $u = (Invoke-Http "$base/api/.well-known/uris").Content | ConvertFrom-Json
    $mgm = if ($u.SecureManagementServer) { $u.SecureManagementServer } else { $u.UnsecureManagementServer }
    $api = if ($u.ApiGateways -and $u.ApiGateways.Count -gt 0) { $u.ApiGateways[0] } else { $null }
    [ordered]@{
        Mgm = $mgm; Idp = $u.IdentityProvider; Api = $api
        Soap = [ordered]@{
            SrvCommand = "${mgm}ManagementServer/ServerCommandService.svc"
            SrvCommandOauth = "${mgm}ManagementServer/ServerCommandServiceOauth.svc"
            SrvRegistrationService = "${mgm}ManagementServer/ServiceRegistrationService.svc"
            SrvRegistrationServiceOAuth = "${mgm}ManagementServer/ServiceRegistrationServiceOAuth.svc"
        }
    }
}

function Invoke-MgmSoap($uris, [string]$oauth, [string]$action, [string]$body, [string]$url = $null) {
    if (-not $url) { $url = $uris.Soap.SrvCommandOauth }
    $r = Invoke-Http $url 'POST' $body @{ Authorization = "Bearer $oauth"; SOAPAction = $action } 'text/xml'
    [xml]$r.Content
}

# returns @{ oauth; xprotect } - cached in token.bin (DPAPI) until 5 minutes before expiry
function Get-Tokens($cfg, $uris) {
    $cache = Join-Path $DIR 'token.bin'
    $now = To-Unix (Get-Date)
    if (Test-Path $cache) {
        try {
            $t = Read-Protected $cache | ConvertFrom-Json
            if ($t.oauth_exp -gt $now + 300 -and $t.xp_exp -gt $now + 300 -and $t.mgm -eq $uris.Mgm -and
                "$($t.auth)" -eq "$($cfg.auth)") { return $t }
        } catch { }
    }
    if ($cfg.api -eq 'legacy') { return (Get-LegacyTokens $cfg $uris) }
    if ($cfg.auth -eq 'windows') {
        # Windows authentication of the account running the script: for the Zabbix agent this is
        # NT AUTHORITY\SYSTEM, which must be a member of a Milestone role. No password stored anywhere.
        $tok = (Invoke-Http "$($uris.Idp)/connect/token" 'POST' 'grant_type=windows_auth&client_id=winauthclient' @{} `
                'application/x-www-form-urlencoded' -windowsAuth).Content | ConvertFrom-Json
    } else {
        $password = Read-Protected (Join-Path $DIR 'credential.bin')
        $form = 'grant_type=password&client_id=GrantValidatorClient&username=' + [Uri]::EscapeDataString($cfg.user) +
                '&password=' + [Uri]::EscapeDataString($password)
        $tok = (Invoke-Http "$($uris.Idp)/connect/token" 'POST' $form @{} 'application/x-www-form-urlencoded').Content |
               ConvertFrom-Json
    }
    if (-not $tok.access_token) { throw 'IDP: no access token' }
    $login = "<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'><s:Body>" +
             "<Login xmlns='http://videoos.net/2/XProtectCSServerCommand'><instanceId>$INSTANCE_ID</instanceId>" +
             "<currentToken /></Login></s:Body></s:Envelope>"
    $x = Invoke-MgmSoap $uris $tok.access_token 'http://videoos.net/2/XProtectCSServerCommand/IServerCommandService/Login' $login
    $res = $x.SelectSingleNode("//*[local-name()='LoginResult']")
    $ttl = [int64]$res.SelectSingleNode("*[local-name()='TimeToLive']/*[local-name()='MicroSeconds']").InnerText / 1000000
    $t = [pscustomobject]@{
        mgm = $uris.Mgm; auth = "$($cfg.auth)"
        oauth = $tok.access_token; oauth_exp = $now + [int64]$tok.expires_in
        xprotect = $res.SelectSingleNode("*[local-name()='Token']").InnerText; xp_exp = $now + $ttl
    }
    Write-Protected $cache ($t | ConvertTo-Json -Compress)
    $t
}

# ---------------------------------------------------------------- info (discovery)
function Get-MobilePort {
    $f = 'C:\Program Files\Milestone\XProtect Mobile Server\VideoOS.MobileServer.Service.exe.config'
    if (Test-Path $f) {
        try {
            [xml]$x = Get-Content $f -Raw
            $n = $x.SelectSingleNode("//HttpMetaChannel/Address/add[@key='Port']")
            if ($n) { return [int]$n.value }
        } catch { }
    }
    8081
}

function Get-Info {
    $cfg = Get-Config
    $uris = Get-Uris $cfg
    $t = Get-Tokens $cfg $uris
    $api = $uris.Api
    $o = $t.oauth

    $pi = Invoke-MgmSoap $uris $o 'http://videoos.net/2/XProtectCSServerCommand/IServerCommandService/GetProductInfo' (
        "<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'><s:Body>" +
        "<GetProductInfo xmlns='http://videoos.net/2/XProtectCSServerCommand'></GetProductInfo></s:Body></s:Envelope>")
    $r = $pi.SelectSingleNode("//*[local-name()='GetProductInfoResult']")
    function v($name) { $n = $r.SelectSingleNode("*[local-name()='$name']"); if ($n) { $n.InnerText } else { '' } }
    $product = [ordered]@{ Name = (v 'ProductName'); Version = ('{0}.{1}.{2}' -f (v 'MajorVersion'), (v 'MinorVersion'), (v 'ServiceVersion')); Slc = (v 'SLC') }

    $mgmServers = @((Get-Json "${api}rest/v1/sites" $o).array | ForEach-Object {
        [ordered]@{ displayName = $_.displayName; id = $_.id; computerName = $_.computerName
                    domainName = $_.domainName; version = $_.version } })

    $recServers = @((Get-Json "${api}rest/v1/recordingServers" $o).array | ForEach-Object {
        $rec = $_
        $storages = @((Get-Json "${api}rest/v1/recordingServers/$($rec.id)/storages" $o).array | ForEach-Object {
            $s = $_
            $archives = @((Get-Json "${api}rest/v1/storages/$($s.id)/archiveStorages" $o).array | ForEach-Object {
                [ordered]@{ displayName = $_.displayName; id = $_.id; path = $_.diskPath; retainMinutes = $_.retainMinutes
                             maxSize = $_.maxSize } })
            [ordered]@{ displayName = $s.displayName; id = $s.id; path = $s.diskPath; retainMinutes = $s.retainMinutes
                        maxSize = $s.maxSize
                        archives = $archives } })
        [ordered]@{ displayName = $rec.displayName; id = $rec.id; enabled = $rec.enabled
                    uri = "$($rec.webServerUri)recorderstatusservice/recorderstatusservice2.asmx"; storages = $storages } })

    # hardware (IP, port, model) and cameras - same fields as the local patch "camera details"
    $hw = @{}
    $devs = @((Get-Json "${api}rest/v1/hardware" $o).array | ForEach-Object {
        $ip = ''; $port = ''
        if ($_.address -match '^(\w+)://([^/:]+)(?::(\d+))?') {
            $ip = $Matches[2]
            $port = if ($Matches[3]) { $Matches[3] } elseif ($Matches[1] -eq 'https') { '443' } else { '80' }
        }
        $d = [ordered]@{ id = $_.id; displayName = $_.displayName; ip = $ip; port = $port; model = "$($_.model)"; enabled = $_.enabled }
        $hw[$_.id] = $d
        $d })
    $cams = @((Get-Json "${api}rest/v1/cameras" $o).array | ForEach-Object {
        $parent = if ($_.relations -and $_.relations.parent) { $_.relations.parent.id } else { '' }
        $h = $hw[$parent]
        $desc = "$($_.description)"; if ($desc.Length -gt 1000) { $desc = $desc.Substring(0, 1000) }   # fields are cut to 250 in the discovery
        # hwEnabled: a camera of disabled hardware is not working either (it is ignored by the discovery)
        [ordered]@{ displayName = $_.displayName; id = $_.id; enabled = $_.enabled
                    hwEnabled = if ($h) { [bool]$h.enabled } else { $true }; storageId = $_.recordingStorage.id
                    shortName = "$($_.shortName)"; description = $desc
                    hwId = if ($h) { $h.id } else { '' }; ip = if ($h) { $h.ip } else { '' }
                    port = if ($h) { $h.port } else { '' }; model = if ($h) { $h.model } else { '' } } })

    # services registered on the Management Server
    $sv = Invoke-MgmSoap $uris $o 'http://schemas.videoos/ServiceRegistrationService/2008/06/Vmo/01/IServiceRegistrationService/GetServices' (
        "<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns='http://schemas.videoos/ServiceRegistrationService/2008/06/Vmo/01'>" +
        "<soapenv:Header/><soapenv:Body><ns:GetServices/></soapenv:Body></soapenv:Envelope>") $uris.Soap.SrvRegistrationServiceOAuth
    $svcs = @($sv.SelectNodes("//*[local-name()='ServiceInfo']") | ForEach-Object {
        $node = $_
        $f = @{}
        foreach ($n in 'name', 'instance', 'type', 'enabled') {
            $x = $node.SelectSingleNode("*[local-name()='$n']")
            $f[$n] = if ($x) { $x.InnerText } else { '' }
        }
        $uriNode = $node.SelectSingleNode("*[local-name()='uri']/*[local-name()='string']")
        [ordered]@{ name = $f.name; instance = $f.instance; uri = if ($uriNode) { $uriNode.InnerText } else { '' }
                    type = $f.type; enabled = $f.enabled } })

    # mobile servers (MIP kind), local URI when the Internet access settings are not configured
    $mobPort = if ($cfg.mob_port) { [int]$cfg.mob_port } else { Get-MobilePort }
    $mobHost = ([Uri]$uris.Mgm).Host
    $mobs = @()
    try {
        $mobs = @((Get-Json "${api}rest/v1/mipKinds/9947f340-397c-483b-9e03-f27253f7f403/mipItems" $o).array | ForEach-Object {
            if ($_.AccessServerIp -and $_.AccessServerPort -and "$($_.AccessServerPort)" -ne '0') {
                $proto = if ("$($_.AccessServerHttps)".ToLower() -eq 'true') { 'https' } else { 'http' }
                $u = "${proto}://$($_.AccessServerIp):$($_.AccessServerPort)"
            } else { $u = "http://${mobHost}:$mobPort" }
            [ordered]@{ displayName = $_.displayName; id = $_.ServerId; uri = $u; version = $_.Version; enabled = $_.enabled } })
    } catch { }
    if ($mobs.Count -eq 0) {
        $mobs = @($svcs | Where-Object { $_.type -eq '7510bbae-dba5-4c2e-b037-74a0222484c6' } | ForEach-Object {
            [ordered]@{ displayName = $_.name; id = $_.instance; uri = $_.uri; version = 'N/A'; enabled = $_.enabled } })
    }

    $info = [ordered]@{
        Product = $product; Uri = $uris
        Srv = [ordered]@{ Mgm = $mgmServers; Rec = $recServers; Mob = $mobs; Svc = $svcs }
        Hw = [ordered]@{ Cam = $cams; Dev = $devs }
        Auth = [ordered]@{ OAuth = [ordered]@{ Token = $null; Expiration = $null }
                           XProtect = [ordered]@{ Token = ''; Expiration = 0 } }   # tokens never leave the server
    }
    $json = $info | ConvertTo-Json -Depth 12 -Compress
    Set-Content -Path (Join-Path $DIR 'info.json') -Value $json -Encoding UTF8
    $json
}

# ---------------------------------------------------------------- status (every minute)
function Invoke-RecSoap([string]$uri, [string]$method, [string]$inner) {
    $action = "http://videoos.net/2/XProtectCSRecorderStatus2/$method"
    $body = "<soap:Envelope xmlns:soap='http://www.w3.org/2003/05/soap-envelope' xmlns:xpr='http://videoos.net/2/XProtectCSRecorderStatus2'>" +
            "<soap:Header/><soap:Body><xpr:$method>$inner</xpr:$method></soap:Body></soap:Envelope>"
    $r = Invoke-Http $uri 'POST' $body @{} "application/soap+xml;charset=UTF-8;action='$action'"
    [xml]$r.Content
}

function Get-Status {
    $infoFile = Join-Path $DIR 'info.json'
    if (-not (Test-Path $infoFile) -or ((Get-Date) - (Get-Item $infoFile).LastWriteTime).TotalHours -gt 2) { Get-InfoAny | Out-Null }
    $info = Get-Content $infoFile -Raw | ConvertFrom-Json
    $cfg = Get-Config
    $t = Get-Tokens $cfg $info.Uri
    $tk = "<xpr:token>$($t.xprotect)</xpr:token>"

    $recState = [ordered]@{}; $cams = @(); $storages = @(); $archives = [ordered]@{}; $arcAll = @()
    foreach ($rec in $info.Srv.Rec) {
        try {
            $x = Invoke-RecSoap $rec.uri 'GetRecorderStatus' $tk
            $recState[$rec.id] = $x.SelectSingleNode("//*[local-name()='ConnectionState']").InnerText
        } catch { $recState[$rec.id] = 'Recorder connection failed'; continue }

        $storageIds = @($rec.storages | ForEach-Object { $_.id })
        $camIds = @($info.Hw.Cam | Where-Object { $storageIds -contains $_.storageId } | ForEach-Object { $_.id })
        if ($camIds.Count -gt 0) {
            $guids = ($camIds | ForEach-Object { "<xpr:guid>$_</xpr:guid>" }) -join ''
            try { $cams += Find-Records (Invoke-RecSoap $rec.uri 'GetCurrentDeviceStatus' "$tk<xpr:deviceIds>$guids</xpr:deviceIds>") 'DeviceId' }
            catch { }
        }
        try { $storages += Find-Records (Invoke-RecSoap $rec.uri 'GetRecordingStorageStatus' $tk) 'StorageId' } catch { }
        try {
            $arc = Find-Records (Invoke-RecSoap $rec.uri 'GetArchiveStorageStatus' $tk) 'StorageId'
            $arcAll += $arc
            # same envelope shape the template preprocessing expects (Zabbix XML.toJson of the SOAP answer)
            foreach ($st in $rec.storages) { foreach ($a in $st.archives) {
                $archives["$($rec.id).$($a.id)"] = @{ Envelope = @{ Body = @{ GetArchiveStorageStatusResponse = @{
                    GetArchiveStorageStatusResult = @{ ArchiveStorageStatus = $arc } } } } }
            } }
        } catch { }
    }
    $svc = [ordered]@{}
    # same services the template discovers (mobile servers, API gateway and a10cd823... are excluded there)
    $skip = '7510bbae-dba5-4c2e-b037-74a0222484c6', 'a10cd823-bb4e-4d31-a162-dd236fc78fa6', 'e46b7bf9-03ce-44eb-bbdc-8ba16d0aaa80'
    foreach ($s in $info.Srv.Svc) {
        if ($s.enabled -eq 'true' -and $s.uri -and $skip -notcontains $s.type) { $svc[$s.instance] = Get-StatusCode $s.uri }
    }
    $mob = [ordered]@{}
    foreach ($m in $info.Srv.Mob) { if ($m.uri) { $mob[$m.id] = Get-StatusCode $m.uri } }

    [ordered]@{ rec = $recState; cam = $cams; storage = $storages; archive = $archives; svc = $svc; mob = $mob
                space = @(Get-StorageSpace $info $storages $arcAll) } |
        ConvertTo-Json -Depth 12 -Compress
}

# Total and free space of the volume (or network share) that holds $path; $null when it cannot be read.
function Get-DiskSpace([string]$path) {
    if (-not ('Zbx.Disk' -as [type])) {
        $sig = '[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] ' +
               'public static extern bool GetDiskFreeSpaceEx(string dir, out ulong freeForUser, out ulong total, out ulong totalFree);'
        Add-Type -Namespace Zbx -Name Disk -MemberDefinition $sig
    }
    # a folder that does not exist yet: ask for its drive / share root
    $p = $path
    if ($p -match '^([A-Za-z]:\\)') { $root = $Matches[1] } elseif ($p -match '^(\\\\[^\\]+\\[^\\]+\\)') { $root = $Matches[1] } else { $root = $p }
    if (-not (Test-Path -LiteralPath $p)) { $p = $root }
    $free = [uint64]0; $total = [uint64]0; $tf = [uint64]0
    if ([Zbx.Disk]::GetDiskFreeSpaceEx($p.TrimEnd('\') + '\', [ref]$free, [ref]$total, [ref]$tf)) {
        return @{ total = $total; free = $free }
    }
    $null
}

# Configured size of each Milestone storage / archive against the real disk under it.
# The "max size" set in Milestone (MB) is a limit, not a reservation: when the disk is smaller (or shared with other
# data) Milestone fills the disk before reaching it, and the retention it promises is not kept.
#   real = used by Milestone + free on the disk = the most this storage can ever hold;  margin = real - max
function Get-StorageSpace($info, $storages, $archives) {
    foreach ($rec in $info.Srv.Rec) {
        foreach ($st in $rec.storages) {
            # chain of stages: live storage, then its archives in order of retention (each archive of the chain keeps
            # recordings longer than the one before). A full stage that has a next one is normal (Milestone moves the
            # oldest data on); only the LAST stage deletes recordings when it is full.
            $arcs = @($st.archives | Where-Object { $_ } | Sort-Object { [int64]$_.retainMinutes })
            $items = @(@{ kind = 'storage'; o = $st; s = @($storages | Where-Object { $_.StorageId -eq $st.id })[0] }) +
                     @($arcs | ForEach-Object { $a = $_; @{ kind = 'archivio'; o = $a
                                                           s = @($archives | Where-Object { $_.StorageId -eq $a.id })[0] } })
            for ($n = 0; $n -lt $items.Count; $n++) {
                $it = $items[$n]
                $o = $it.o
                $max = if ("$($o.maxSize)" -match '^\d+$' -and [int64]$o.maxSize -gt 0) { [int64]$o.maxSize * 1MB } else { $null }
                $used = if ($it.s -and "$($it.s.UsedSpaceInBytes)" -match '^\d+$') { [int64]$it.s.UsedSpaceInBytes } else { $null }
                $disk = if ($o.path) { Get-DiskSpace "$($o.path)" } else { $null }
                $real = if ($disk -and $null -ne $used) { [int64]$used + [int64]$disk.free } else { $null }
                [ordered]@{
                    id = "$($o.id)"; kind = $it.kind; rec = "$($rec.displayName)"; name = "$($o.displayName)"; path = "$($o.path)"
                    max = $max; used = $used
                    disk_total = $(if ($disk) { [int64]$disk.total } else { $null })
                    disk_free = $(if ($disk) { [int64]$disk.free } else { $null })
                    real = $real; margin = $(if ($null -ne $real -and $null -ne $max) { $real - $max } else { $null })
                    # free part of the configured max size, in % (same as "space available" of Milestone)
                    pfree = $(if ($null -ne $max -and $null -ne $used) { [math]::Round([math]::Max(0, ($max - $used) * 100.0 / $max), 1) } else { $null })
                    stage = $n + 1; stages = $items.Count; last = [int]($n -eq $items.Count - 1)
                    next = $(if ($n -lt $items.Count - 1) { "$($items[$n + 1].o.displayName)" } else { '' })
                }
            }
        }
    }
}

# ---------------------------------------------------------------- retention (every hour)
# Actual retention per camera = age of its oldest recording table. The media database has one folder per camera
# and per hour, named <cameraGuid>_<KIND>_<yyyy-MM-dd_HH-mm-ss> (end of the hour, local time): only folder NAMES
# are read, nothing is opened. Configured retention = longest of the storage and of its archives.
function Get-TableNames([string]$path, [string]$re) {
    # names of the table folders in $path or one level below; a table folder itself is never opened
    $out = New-Object System.Collections.Generic.List[string]
    try { $top = @([IO.Directory]::EnumerateDirectories($path)) } catch { return $out }
    foreach ($full in $top) {
        $name = [IO.Path]::GetFileName($full)
        if ($name -match $re) { $out.Add($name); continue }
        try { foreach ($sub in [IO.Directory]::EnumerateDirectories($full)) { $out.Add([IO.Path]::GetFileName($sub)) } } catch { }
    }
    $out
}

# Retention: the scan of the recording folders runs in the BACKGROUND (mode retention-build) and writes
# retention.json; the agent item (mode retention) only reads that file. Even reading folder names only, archives on
# NAS took more than the 120 s item timeout (L'AQUILA 3 archives on NAS, FOGGIA, 2026-11-22). 1.2.0.
$RET_FILE = Join-Path $DIR 'retention.json'
$RET_LOCK = Join-Path $DIR 'retention.lock'
$RET_ERR = Join-Path $DIR 'retention.err'     # last error of the background scan
$RET_EVERY_MIN = 50        # a new scan when the file is older than this
$RET_LOCK_HOURS = 6        # a scan still "running" after this is considered dead (lock ignored)
$RET_STALE_HOURS = 6       # older data -> item error, so the triggers do not work on old values

function Build-Retention {
    $start = Get-Date
    $infoFile = Join-Path $DIR 'info.json'
    if (-not (Test-Path $infoFile) -or ((Get-Date) - (Get-Item $infoFile).LastWriteTime).TotalHours -gt 2) { Get-InfoAny | Out-Null }
    $info = Get-Content $infoFile -Raw | ConvertFrom-Json
    $re = '^([0-9a-fA-F-]{36})_[A-Za-z]+_(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})$'
    $oldest = @{}; $cfg = @{}
    $scanned = New-Object System.Collections.Generic.List[object]
    foreach ($rec in $info.Srv.Rec) { foreach ($st in $rec.storages) {
        $minutes = @([int64]$st.retainMinutes) + @($st.archives | ForEach-Object { [int64]$_.retainMinutes })
        $cfg[$st.id] = ($minutes | Measure-Object -Maximum).Maximum
        $paths = @(Join-Path $st.path $st.id) + @($st.archives | ForEach-Object { $_.path })
        foreach ($p in $paths) {
            $t0 = Get-Date
            if (-not $p -or -not (Test-Path -LiteralPath $p)) { $scanned.Add([ordered]@{ path = "$p"; ok = 0 }); continue }
            # storage: <path>\<storageId>\<table>   archive: <path>\...\<table> (one level more at most).
            # Only the folder NAMES are read, never the inside of a table folder (one folder per camera and hour).
            $n = 0
            foreach ($d in (Get-TableNames $p $re)) {
                if ($d -match $re) {
                    $n++
                    $cam = $Matches[1].ToLower()
                    $t = [datetime]::ParseExact($Matches[2], 'yyyy-MM-dd_HH-mm-ss', $null).AddHours(-1)
                    if (-not $oldest.ContainsKey($cam) -or $t -lt $oldest[$cam]) { $oldest[$cam] = $t }
                }
            }
            # time per path: shows which storage/archive is slow
            $scanned.Add([ordered]@{ path = "$p"; ok = 1; tables = $n; seconds = [math]::Round(((Get-Date) - $t0).TotalSeconds, 1) })
        }
    } }
    $cams = [ordered]@{}
    foreach ($c in $info.Hw.Cam) {
        $id = "$($c.id)".ToLower()
        if (-not $oldest.ContainsKey($id)) { continue }          # never recorded: nothing to compare
        $cams[$c.id] = [ordered]@{ cfg_days = [math]::Round([double]$cfg[$c.storageId] / 1440, 2); oldest = To-Unix $oldest[$id] }
    }
    $out = [ordered]@{ built = (To-Unix (Get-Date)); seconds = [math]::Round(((Get-Date) - $start).TotalSeconds, 1)
                       paths = $scanned; cam = $cams } | ConvertTo-Json -Depth 5 -Compress
    $tmp = "$RET_FILE.tmp"
    [IO.File]::WriteAllText($tmp, $out, (New-Object Text.UTF8Encoding $false))
    Move-Item -LiteralPath $tmp -Destination $RET_FILE -Force
}

function Start-RetentionBuild {
    # a process outside the agent's process tree (WMI): the agent does not wait for it and does not kill it
    if ((Test-Path $RET_LOCK) -and ((Get-Date) - (Get-Item $RET_LOCK).LastWriteTime).TotalHours -lt $RET_LOCK_HOURS) { return }
    Set-Content -LiteralPath $RET_LOCK -Value (Get-Date -Format s) -Encoding ASCII
    $cmd = 'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "{0}" retention-build -DataDir "{1}"' -f $PSCommandPath, $DIR
    $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cmd; CurrentDirectory = $DIR }
    if ($r.ReturnValue -ne 0) { Remove-Item -LiteralPath $RET_LOCK -Force -ErrorAction SilentlyContinue; throw "avvio calcolo conservazione fallito ($($r.ReturnValue))" }
}

function Get-Retention {
    $age = if (Test-Path $RET_FILE) { ((Get-Date) - (Get-Item $RET_FILE).LastWriteTime).TotalMinutes } else { [double]::MaxValue }
    if ($age -gt $RET_EVERY_MIN) { Start-RetentionBuild }
    $err = if (Test-Path $RET_ERR) { ' - ultimo errore: ' + (Get-Content -LiteralPath $RET_ERR -Raw).Trim() } else { '' }
    if (-not (Test-Path $RET_FILE)) { throw "conservazione: primo calcolo in corso, dati tra qualche minuto$err" }
    if ($age -gt $RET_STALE_HOURS * 60) { throw ("conservazione: dati vecchi di {0:N0} ore, il calcolo non finisce{1}" -f ($age / 60), $err) }
    $r = Get-Content -LiteralPath $RET_FILE -Raw | ConvertFrom-Json
    # days counted NOW from the oldest recording: they keep growing between two scans
    $now = Get-Date
    $cams = [ordered]@{}
    foreach ($p in $r.cam.PSObject.Properties) {
        $oldestT = [DateTimeOffset]::FromUnixTimeSeconds([int64]$p.Value.oldest).LocalDateTime
        $cams[$p.Name] = [ordered]@{ days = [math]::Round(($now - $oldestT).TotalDays, 2); cfg_days = $p.Value.cfg_days; oldest = $p.Value.oldest }
    }
    [ordered]@{ built = $r.built; seconds = $r.seconds; age_min = [math]::Round($age, 0); paths = $r.paths; cam = $cams } |
        ConvertTo-Json -Depth 5 -Compress
}

# ---------------------------------------------------------------- licenses (every hour)
function Get-License {
    $cfg = Get-Config
    $uris = Get-Uris $cfg
    $o = (Get-Tokens $cfg $uris).oauth
    $api = $uris.Api
    function list($path) { $r = Get-Json "${api}rest/v1/$path" $o; if ($r.array) { @($r.array) } else { @() } }
    function byType($l, $type) { $x = $l | Where-Object { $_.licenseType -eq $type } | Select-Object -First 1; if ($x) { $x } else { [pscustomobject]@{} } }
    function int($v) { $n = 0; if ([int]::TryParse("$v", [ref]$n)) { $n } else { 0 } }

    $info = (list 'licenseInformations') | Select-Object -First 1
    $dev = byType (list 'licenseDetails') 'Device License'
    $devOv = byType (list 'licenseOverviewAll') 'Device License'
    $available = 0
    if ("$($devOv.activated)" -match '(\d+)\s+out of\s+(\S+)') { $available = int $Matches[2] }
    $lines = foreach ($rec in (list 'recordingServers')) {
        foreach ($s in (list "recordingServers/$($rec.id)/storages")) {
            '{0} / {1} ({2}): max {3} GB, conserva {4} giorni' -f $rec.displayName, $s.displayName, $s.diskPath,
                [math]::Round((int $s.maxSize) / 1024), [math]::Round((int $s.retainMinutes) / 1440)
        }
    }
    $ingrace = int $dev.inGrace
    $summary = if ($devOv.activated) { "$($devOv.activated)".Replace('out of', 'di') } else { 'n/d' }
    $summary += ' attivate'
    if ($ingrace -gt 0) { $summary += ", $ingrace in grazia" }
    [ordered]@{
        storage_config = ($lines -join "`n")
        product = "$($info.displayName)"; slc = "$($info.slc)"; care = "$($info.careLevel)"
        dev_activated = int $dev.activated; dev_available = $available; dev_ingrace = $ingrace
        dev_graceexpired = int $dev.graceExpired; dev_notlicensed = int $dev.notLicensed; summary = $summary
    } | ConvertTo-Json -Compress
}

# ---------------------------------------------------------------- legacy mode (XProtect without API Gateway, e.g. 2020 R3)
# config.json "api": "legacy". No REST API and no OAuth SOAP on these versions: lists and licenses are read with
# MilestonePSTools, connected as the Windows user running the script (the Zabbix agent account, e.g. Administrator);
# the XProtect token for RecorderStatus2 comes from the same connection (Get-VmsToken) and is cached (DPAPI).
# Output = same JSON as the REST mode (ids in lower case, like the REST API and RecorderStatus2).
# MilestonePSTools renamed some commands over the versions (e.g. Get-LicensedProducts -> Get-VmsLicensedProducts):
# the legacy mode calls them through these variables, set to the name available in the installed module.
$PST = @{}
function Resolve-PSTools {
    $names = [ordered]@{
        'Get-VmsManagementServer' = @('Get-VmsManagementServer', 'Get-ManagementServer')
        'Get-VmsRecordingServer' = @('Get-VmsRecordingServer', 'Get-RecordingServer')
        'Get-VmsStorage' = @('Get-VmsStorage')
        'Get-VmsArchiveStorage' = @('Get-VmsArchiveStorage', 'Get-ArchiveStorage')
        'Get-VmsHardware' = @('Get-VmsHardware', 'Get-Hardware')
        'Get-VmsCamera' = @('Get-VmsCamera')
        'Get-VmsToken' = @('Get-VmsToken', 'Get-Token')
        'Get-VmsLicenseInfo' = @('Get-VmsLicenseInfo', 'Get-LicenseInfo')
        'Get-VmsLicenseDetails' = @('Get-VmsLicenseDetails', 'Get-LicenseDetails')
        'Get-VmsLicenseOverview' = @('Get-VmsLicenseOverview', 'Get-LicenseOverview')
        'Get-VmsLicensedProducts' = @('Get-VmsLicensedProducts', 'Get-LicensedProducts')
    }
    foreach ($k in $names.Keys) {
        $found = $names[$k] | Where-Object { Get-Command $_ -ErrorAction SilentlyContinue } | Select-Object -First 1
        $script:PST[$k] = if ($found) { $found } else { $k }      # missing: the call fails with a clear name
    }
}

function Connect-Legacy($cfg) {
    Import-Module MilestonePSTools -ErrorAction Stop
    Resolve-PSTools
    # NB: -NoProfile makes Connect-Vms hang (tested): the default connection profile of the user is used/saved
    Connect-Vms -ServerAddress $cfg.mgm_url -AcceptEula -ErrorAction Stop | Out-Null
}

function Save-LegacyToken($cfg, $uris) {
    $now = To-Unix (Get-Date)
    $tk = "$(& $PST['Get-VmsToken'])"
    if (-not $tk) { throw 'MilestonePSTools: no token' }
    # the token normally lasts 4 hours: renewed after 1
    $t = [pscustomobject]@{ mgm = $uris.Mgm; auth = "$($cfg.auth)"; oauth = ''; oauth_exp = $now + 3600
                            xprotect = $tk; xp_exp = $now + 3600 }
    Write-Protected (Join-Path $DIR 'token.bin') ($t | ConvertTo-Json -Compress)
    $t
}

function Get-LegacyTokens($cfg, $uris) {
    Connect-Legacy $cfg
    try { Save-LegacyToken $cfg $uris } finally { Disconnect-Vms -ErrorAction SilentlyContinue }
}

function Get-LegacyUris($cfg) {
    $mgm = $cfg.mgm_url.TrimEnd('/') + '/'
    [ordered]@{ Mgm = $mgm; Idp = $null; Api = $null
                Soap = [ordered]@{ SrvCommand = "${mgm}ManagementServer/ServerCommandService.svc"; SrvCommandOauth = $null
                                   SrvRegistrationService = $null; SrvRegistrationServiceOAuth = $null } }
}

function Lid($v) { "$v".ToLower() }

function Get-InfoLegacy {
    $cfg = Get-Config
    $uris = Get-LegacyUris $cfg
    Connect-Legacy $cfg
    try {
        $ms = & $PST['Get-VmsManagementServer']
        # product name and SLC are not essential: a missing command must not stop the discovery
        $prod = try { @(& $PST['Get-VmsLicensedProducts'] | Where-Object { "$($_.ProductDisplayName)" -match 'XProtect' }) | Select-Object -First 1 } catch { $null }
        $lic = try { & $PST['Get-VmsLicenseInfo'] } catch { $null }
        $product = [ordered]@{ Name = if ($prod) { "$($prod.ProductDisplayName)" } else { "XProtect $($ms.Version)" }
                               Version = "$($ms.Version)"; Slc = "$($lic.Slc)" }
        $mgmServers = @([ordered]@{ displayName = "$($ms.Name)"; id = Lid $ms.Id; computerName = "$($ms.Name)"
                                    domainName = ''; version = "$($ms.Version)" })
        $recs = @(); $devs = @(); $cams = @()
        foreach ($rec in (& $PST['Get-VmsRecordingServer'])) {
            $storages = @(foreach ($st in ($rec | & $PST['Get-VmsStorage'])) {
                $archives = @(foreach ($a in @($st | & $PST['Get-VmsArchiveStorage'] -ErrorAction SilentlyContinue)) {
                    [ordered]@{ displayName = "$($a.Name)"; id = Lid $a.Id; path = "$($a.DiskPath)"; retainMinutes = $a.RetainMinutes
                                 maxSize = $a.MaxSize } })
                [ordered]@{ displayName = "$($st.Name)"; id = Lid $st.Id; path = "$($st.DiskPath)"; retainMinutes = $st.RetainMinutes
                            maxSize = $st.MaxSize
                            archives = $archives } })
            $recs += [ordered]@{ displayName = "$($rec.Name)"; id = Lid $rec.Id; enabled = [bool]$rec.Enabled
                                 uri = "$($rec.WebServerUri)".TrimEnd('/') + '/recorderstatusservice/recorderstatusservice2.asmx'
                                 storages = $storages }
            foreach ($hw in ($rec | & $PST['Get-VmsHardware'])) {
                $ip = ''; $port = ''
                if ("$($hw.Address)" -match '^(\w+)://([^/:]+)(?::(\d+))?') {
                    $ip = $Matches[2]
                    $port = if ($Matches[3]) { $Matches[3] } elseif ($Matches[1] -eq 'https') { '443' } else { '80' }
                }
                $devs += [ordered]@{ id = Lid $hw.Id; displayName = "$($hw.Name)"; ip = $ip; port = $port; model = "$($hw.Model)"
                                     enabled = [bool]$hw.Enabled }
                foreach ($cam in @($hw | & $PST['Get-VmsCamera'] -EnableFilter All)) {
                    $desc = "$($cam.Description)"; if ($desc.Length -gt 1000) { $desc = $desc.Substring(0, 1000) }
                    $storageId = if ("$($cam.RecordingStorage)" -match '([0-9a-fA-F-]{36})') { Lid $Matches[1] } else { '' }
                    $cams += [ordered]@{ displayName = "$($cam.Name)"; id = Lid $cam.Id; enabled = [bool]$cam.Enabled
                                         hwEnabled = [bool]$hw.Enabled; storageId = $storageId; shortName = "$($cam.ShortName)"
                                         description = $desc; hwId = Lid $hw.Id; ip = $ip; port = $port; model = "$($hw.Model)" }
                }
            }
        }
        # mobile server: local service, port from its configuration, version from the installed programs
        $mobs = @()
        if (Get-Service -Name 'Milestone XProtect Mobile Server' -ErrorAction SilentlyContinue) {
            $ver = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                                     'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue |
                    Where-Object { $_.DisplayName -match 'Mobile Server' -and $_.DisplayVersion -notmatch '^1\.0\.0' } |
                    Select-Object -First 1).DisplayVersion
            $mobPort = if ($cfg.mob_port) { [int]$cfg.mob_port } else { Get-MobilePort }
            $mobs = @([ordered]@{ displayName = $env:COMPUTERNAME; id = "mobile-$($env:COMPUTERNAME.ToLower())"
                                  uri = "http://$(([Uri]$uris.Mgm).Host):$mobPort"; version = "$ver"; enabled = $true })
        }
        $null = Save-LegacyToken $cfg $uris          # token for the status checks of the next hour
    } finally { Disconnect-Vms -ErrorAction SilentlyContinue }

    $info = [ordered]@{
        Product = $product; Uri = $uris
        Srv = [ordered]@{ Mgm = $mgmServers; Rec = $recs; Mob = $mobs; Svc = @() }   # no service registration list
        Hw = [ordered]@{ Cam = $cams; Dev = $devs }
        Auth = [ordered]@{ OAuth = [ordered]@{ Token = $null; Expiration = $null }; XProtect = [ordered]@{ Token = ''; Expiration = 0 } }
    }
    $json = $info | ConvertTo-Json -Depth 12 -Compress
    Set-Content -Path (Join-Path $DIR 'info.json') -Value $json -Encoding UTF8
    $json
}

# Device (camera) license among the license rows: "Device License" in recent versions; older or localized versions
# may name it differently, but it is always the core row with an empty PluginId.
function Select-DeviceLicense($rows) {
    $r = $rows | Where-Object { "$($_.LicenseType)" -eq 'Device License' } | Select-Object -First 1
    if (-not $r) { $r = $rows | Where-Object { "$($_.LicenseType)" -match 'device|dispositiv|camera|telecamer' } | Select-Object -First 1 }
    if (-not $r) { $r = $rows | Where-Object { "$($_.PluginId)" -match '^0{8}-0{4}-0{4}-0{4}-0{12}$' } | Select-Object -First 1 }
    $r
}

function Get-Prop($o, [string[]]$names) {
    if (-not $o) { return $null }
    foreach ($n in $names) { if ($o.PSObject.Properties[$n]) { return $o.$n } }
    $null
}

function Get-LicenseLegacy {
    $cfg = Get-Config
    Connect-Legacy $cfg
    try {
        function int($v) { $n = 0; if ([int]::TryParse("$v", [ref]$n)) { $n } else { 0 } }
        $info = & $PST['Get-VmsLicenseInfo'] -ErrorAction SilentlyContinue
        $prod = @(& $PST['Get-VmsLicensedProducts'] -ErrorAction SilentlyContinue | Where-Object { "$($_.ProductDisplayName)" -match 'XProtect' }) | Select-Object -First 1
        $dev = Select-DeviceLicense @(& $PST['Get-VmsLicenseDetails'] -ErrorAction SilentlyContinue)
        $ov = Select-DeviceLicense @(& $PST['Get-VmsLicenseOverview'] -ErrorAction SilentlyContinue)
        $actText = "$(Get-Prop $ov @('Activated', 'ActivatedText', 'Activated_'))"
        $available = 0
        if ($actText -match '(\d+)\s+(?:out of|di|of|/)\s+(\S+)') { $available = int $Matches[2] }
        $lines = foreach ($rec in (& $PST['Get-VmsRecordingServer'])) { foreach ($s in ($rec | & $PST['Get-VmsStorage'])) {
            '{0} / {1} ({2}): max {3} GB, conserva {4} giorni' -f $rec.Name, $s.Name, $s.DiskPath,
                [math]::Round((int $s.MaxSize) / 1024), [math]::Round((int $s.RetainMinutes) / 1440) } }
        $ingrace = int (Get-Prop $dev @('InGrace', 'InGracePeriod'))
        $summary = if ($actText) { $actText.Replace('out of', 'di') } else { 'n/d' }
        $summary += ' attivate'
        if ($ingrace -gt 0) { $summary += ", $ingrace in grazia" }
        [ordered]@{
            storage_config = ($lines -join "`n"); product = "$($prod.ProductDisplayName)"; slc = "$($info.Slc)"
            care = "$($info.CareLevel)"; dev_activated = int (Get-Prop $dev @('Activated')); dev_available = $available
            dev_ingrace = $ingrace; dev_graceexpired = int (Get-Prop $dev @('GraceExpired'))
            dev_notlicensed = int (Get-Prop $dev @('NotLicensed')); summary = $summary
        } | ConvertTo-Json -Compress
    } finally { Disconnect-Vms -ErrorAction SilentlyContinue }
}

function Get-InfoAny { if ((Get-Config).api -eq 'legacy') { Get-InfoLegacy } else { Get-Info } }

# ---------------------------------------------------------------- NAS (every 5 minutes)
# NAS in the LAN of the video server, found from the network paths Milestone and the Smart Client use
# (archives, storages, export folder: \\host\share) plus config.json "nas_hosts". For each NAS:
#   - SMB reachability (TCP 445) and free/total space of every share used (GetDiskFreeSpaceEx works on UNC paths,
#     no drive letter needed)
#   - health through SNMP v2c (read-only community, DPAPI in snmp.bin): QNAP NAS-MIB 1.3.6.1.4.1.24681.1.2
#     (disks + SMART, volumes, fans, temperatures, CPU, memory) and MIB-2 system name/description/uptime.
# The SNMP client is written here (Windows has none): GET and GETBULK v2c over UDP 161 (or the port found by
# Find-SnmpPort: cache snmp_ports.json, config.json "snmp_ports", default 161 and 1619).


function Snmp-Len([int]$n) {
    if ($n -lt 128) { return ,[byte[]]@([byte]$n) }
    if ($n -lt 256) { return ,[byte[]]@([byte]0x81, [byte]$n) }
    ,[byte[]]@([byte]0x82, [byte]($n -shr 8), [byte]($n -band 255))
}
function Snmp-Tlv([int]$tag, [byte[]]$content) {
    if ($null -eq $content) { $content = [byte[]]@() }
    $l = New-Object System.Collections.Generic.List[byte]
    $l.Add([byte]$tag); $l.AddRange([byte[]](Snmp-Len $content.Length)); $l.AddRange($content)
    ,$l.ToArray()
}
function Snmp-Int([int]$v) {
    $b = [BitConverter]::GetBytes([int32]$v); [array]::Reverse($b)
    $i = 0
    while ($i -lt 3 -and (($b[$i] -eq 0 -and ($b[$i + 1] -band 0x80) -eq 0) -or ($b[$i] -eq 0xFF -and ($b[$i + 1] -band 0x80) -ne 0))) { $i++ }
    Snmp-Tlv 0x02 ([byte[]]$b[$i..3])
}
function Snmp-Oid([string]$oid) {
    $p = @($oid.Trim('.').Split('.') | ForEach-Object { [uint64]$_ })
    $l = New-Object System.Collections.Generic.List[byte]
    $l.Add([byte](40 * $p[0] + $p[1]))
    for ($i = 2; $i -lt $p.Count; $i++) {
        $v = $p[$i]; $chunk = New-Object System.Collections.Generic.List[byte]
        $chunk.Add([byte]($v -band 0x7F)); $v = $v -shr 7
        while ($v -gt 0) { $chunk.Insert(0, [byte](($v -band 0x7F) -bor 0x80)); $v = $v -shr 7 }
        $l.AddRange($chunk)
    }
    Snmp-Tlv 0x06 $l.ToArray()
}
function Snmp-ReadTlv([byte[]]$b, [int]$pos) {
    $tag = $b[$pos]; $len = [int]$b[$pos + 1]; $hdr = 2
    if ($len -band 0x80) {
        $n = $len -band 0x7F; $len = 0
        for ($i = 0; $i -lt $n; $i++) { $len = ($len -shl 8) -bor $b[$pos + 2 + $i] }
        $hdr = 2 + $n
    }
    @{ tag = $tag; start = $pos + $hdr; len = $len; next = $pos + $hdr + $len }
}
function Snmp-DecodeOid([byte[]]$b, [int]$start, [int]$len) {
    $first = [int]$b[$start]; $x1 = [int][math]::Floor($first / 40); $x2 = $first % 40
    $parts = @($x1, $x2); $v = [uint64]0
    for ($i = $start + 1; $i -lt $start + $len; $i++) {
        $v = ($v -shl 7) -bor ($b[$i] -band 0x7F)
        if (($b[$i] -band 0x80) -eq 0) { $parts += $v; $v = [uint64]0 }
    }
    ($parts -join '.')
}
function Snmp-DecodeValue([byte[]]$b, $t) {
    switch ($t.tag) {
        0x02 { $v = [int64]0; if ($t.len -gt 0 -and ($b[$t.start] -band 0x80)) { $v = -1 }
               for ($i = 0; $i -lt $t.len; $i++) { $v = ($v -shl 8) -bor $b[$t.start + $i] }; return $v }
        { $_ -in 0x41, 0x42, 0x43, 0x46 } { $v = [uint64]0; for ($i = 0; $i -lt $t.len; $i++) { $v = ($v -shl 8) -bor $b[$t.start + $i] }; return $v }
        0x04 { return [Text.Encoding]::UTF8.GetString($b, $t.start, $t.len).Trim([char]0).Trim() }
        0x06 { return (Snmp-DecodeOid $b $t.start $t.len) }
        0x40 { return (($b[$t.start..($t.start + 3)]) -join '.') }
        default { return $null }     # NULL, noSuchObject (0x80), noSuchInstance (0x81), endOfMibView (0x82)
    }
}
# One request; returns an ordered list of @{ oid; value; end } (end = endOfMibView / no such object).
# UDP port per NAS (some QNAP are set to another port than 161, e.g. 1619 at FOGGIA): see Find-SnmpPort
$script:SnmpPort = @{}
$script:SnmpTries = 3
$script:SnmpTimeout = 4000

# Port where the NAS answers SNMP: the one that worked last time (snmp_ports.json, cache), then config.json
# "snmp_ports" (list), else 161 and 1619. Quick probe (1 try, 2.5 s each) so a wrong port costs little.
function Find-SnmpPort([string]$h, [string]$community) {
    $cacheFile = Join-Path $DIR 'snmp_ports.json'
    $cache = @{}
    if (Test-Path $cacheFile) {
        try { (Get-Content $cacheFile -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $cache[$_.Name] = [int]$_.Value } } catch { }
    }
    $cfgPorts = @((Get-Config).snmp_ports | Where-Object { "$_" -match '^\d+$' } | ForEach-Object { [int]$_ })
    $candidates = @(@($cache[$h]) + $(if ($cfgPorts.Count) { $cfgPorts } else { @(161, 1619) }) |
        Where-Object { $_ } | Select-Object -Unique)
    $tries = $script:SnmpTries; $timeout = $script:SnmpTimeout
    $script:SnmpTries = 1; $script:SnmpTimeout = 2500
    try {
        foreach ($p in $candidates) {
            $script:SnmpPort[$h] = $p
            try {
                [void](Snmp-Get $h $community @('1.3.6.1.2.1.1.5.0'))
                if ($cache[$h] -ne $p) {
                    $cache[$h] = $p
                    try { $cache | ConvertTo-Json -Compress | Set-Content $cacheFile -Encoding ASCII } catch { }
                }
                return $p
            } catch { }
        }
    } finally { $script:SnmpTries = $tries; $script:SnmpTimeout = $timeout }
    $script:SnmpPort.Remove($h)
    throw "SNMP: no answer from $h (porte UDP provate: $($candidates -join ', '))"
}

function Snmp-Request([string]$hostName, [string]$community, [int]$pduType, [string[]]$oids, [int]$a = 0, [int]$b = 0) {
    $vbs = New-Object System.Collections.Generic.List[byte]
    foreach ($o in $oids) { $vbs.AddRange([byte[]](Snmp-Tlv 0x30 ([byte[]]((Snmp-Oid $o) + (Snmp-Tlv 0x05 $null))))) }
    $reqId = Get-Random -Minimum 1 -Maximum 2000000000
    $pdu = Snmp-Tlv $pduType ([byte[]]((Snmp-Int $reqId) + (Snmp-Int $a) + (Snmp-Int $b) + (Snmp-Tlv 0x30 $vbs.ToArray())))
    $msg = Snmp-Tlv 0x30 ([byte[]]((Snmp-Int 1) + (Snmp-Tlv 0x04 ([Text.Encoding]::ASCII.GetBytes($community))) + $pdu))
    # IPv4 only: a NAS name can resolve to an IPv6 address first, which an IPv4 UDP socket cannot reach
    $addr = $null
    if (-not [Net.IPAddress]::TryParse($hostName, [ref]$addr) -or $addr.AddressFamily -ne 'InterNetwork') {
        $addr = [Net.Dns]::GetHostAddresses($hostName) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1
        if (-not $addr) { throw "SNMP: no IPv4 address for $hostName" }
    }
    $port = if ($script:SnmpPort.ContainsKey($hostName)) { $script:SnmpPort[$hostName] } else { 161 }
    $target = New-Object Net.IPEndPoint($addr, $port)
    $udp = New-Object Net.Sockets.UdpClient([Net.Sockets.AddressFamily]::InterNetwork)
    $udp.Client.ReceiveTimeout = $script:SnmpTimeout
    try {
        $resp = $null
        for ($try = 0; $try -lt $script:SnmpTries -and -not $resp; $try++) {
            [void]$udp.Send($msg, $msg.Length, $target)
            $ep = New-Object Net.IPEndPoint([Net.IPAddress]::Any, 0)
            try { $resp = $udp.Receive([ref]$ep) } catch { }
        }
    } finally { $udp.Close() }
    if (-not $resp) { throw "SNMP: no answer from $hostName (UDP $port)" }
    $m = Snmp-ReadTlv $resp 0
    $p = Snmp-ReadTlv $resp $m.start                   # version
    $p = Snmp-ReadTlv $resp $p.next                    # community
    $pd = Snmp-ReadTlv $resp $p.next                   # response PDU
    $p = Snmp-ReadTlv $resp $pd.start                  # request id
    $es = Snmp-ReadTlv $resp $p.next                   # error status
    $ei = Snmp-ReadTlv $resp $es.next                  # error index
    $list = Snmp-ReadTlv $resp $ei.next
    $out = @(); $pos = $list.start
    while ($pos -lt $list.next) {
        $vb = Snmp-ReadTlv $resp $pos
        $o = Snmp-ReadTlv $resp $vb.start
        $v = Snmp-ReadTlv $resp $o.next
        $out += @{ oid = (Snmp-DecodeOid $resp $o.start $o.len); value = (Snmp-DecodeValue $resp $v); end = ($v.tag -ge 0x80) }
        $pos = $vb.next
    }
    $out
}
function Snmp-Get([string]$h, [string]$c, [string[]]$oids) {
    $r = @{}; foreach ($x in (Snmp-Request $h $c 0xA0 $oids)) { if (-not $x.end) { $r[$x.oid] = $x.value } }; $r
}
function Snmp-Walk([string]$h, [string]$c, [string]$base, [int]$max = 3000) {
    $r = [ordered]@{}; $cur = $base.Trim('.')
    while ($r.Count -lt $max) {
        $batch = Snmp-Request $h $c 0xA5 @($cur) 0 30          # GETBULK, max-repetitions 30
        if (-not $batch) { break }
        $stop = $false
        foreach ($x in $batch) {
            if ($x.end -or -not $x.oid.StartsWith("$($base.Trim('.')).")) { $stop = $true; break }
            $r[$x.oid] = $x.value; $cur = $x.oid
        }
        if ($stop) { break }
    }
    $r
}

function Get-Number([string]$text) {           # "37 C/98 F" -> 37, "1200 RPM" -> 1200
    if ("$text" -match '(-?\d+(?:[.,]\d+)?)') { return [double]($Matches[1].Replace(',', '.')) }
    $null
}
function Get-Bytes([string]$text) {            # "3.58 TB" -> bytes
    if ("$text" -match '([\d.,]+)\s*([KMGTP]?)B') {
        $n = [double]($Matches[1].Replace(',', '.'))
        $mult = @{ '' = 1; 'K' = 1KB; 'M' = 1MB; 'G' = 1GB; 'T' = 1TB; 'P' = 1PB }[$Matches[2]]
        return [int64]($n * $mult)
    }
    $null
}

# QNAP legacy NAS-MIB, table columns by index (from the walk of 1.3.6.1.4.1.24681.1.2)
function Get-QnapHealth([string]$h, [string]$c) {
    $base = '1.3.6.1.4.1.24681.1.2'
    $w = Snmp-Walk $h $c $base
    $sys = Snmp-Get $h $c @('1.3.6.1.2.1.1.1.0', '1.3.6.1.2.1.1.3.0', '1.3.6.1.2.1.1.5.0')
    function col($table, $col) {
        $res = [ordered]@{}
        foreach ($k in $w.Keys) { if ($k -match "^$([regex]::Escape("$base.$table.1.$col")).(\d+)$") { $res[$Matches[1]] = $w[$k] } }
        $res
    }
    $disks = @()
    $dDescr = col 11 2; $dTemp = col 11 3; $dStat = col 11 4; $dModel = col 11 5; $dCap = col 11 6; $dSmart = col 11 7
    foreach ($i in $dDescr.Keys) {
        $disks += [ordered]@{ idx = "$i"; descr = "$($dDescr[$i])"; temp = (Get-Number $dTemp[$i]); status = $dStat[$i]
                              model = "$($dModel[$i])".Trim(); capacity = "$($dCap[$i])"; smart = "$($dSmart[$i])" }
    }
    $vols = @()
    $vDescr = col 17 2; $vFs = col 17 3; $vTot = col 17 4; $vFree = col 17 5; $vStat = col 17 6
    foreach ($i in $vDescr.Keys) {
        $t = Get-Bytes $vTot[$i]; $f = Get-Bytes $vFree[$i]
        $vols += [ordered]@{ idx = "$i"; descr = "$($vDescr[$i])"; fs = "$($vFs[$i])"; status = "$($vStat[$i])"
                             total = $t; free = $f; used = if ($null -ne $t -and $null -ne $f) { $t - $f } else { $null }
                             pfree = if ($t -gt 0) { [math]::Round($f / $t * 100, 1) } else { $null } }
    }
    # disk size in bytes from the legacy text ("3.64 TB"); refined below by the QTS 4.4+ table when the NAS has it
    foreach ($d in $disks) { $d.bytes = Get-Bytes $d.capacity; $d.spare = $null; $d.empty = [int]("$($d.status)" -eq '-5') }
    # QTS 4.4+ / QTS 5 storage tables (NAS-MIB 1.3.6.1.4.1.24681.1.4.1.1.1, GETBULK, a few requests):
    #   diskTable    .1.5.2.1  2 diskID  4 summary  7 global spare (0 no, 1 yes)  8 model  9 capacity (bytes)
    #   raidGroup    .2.1.2.1  2 id  3 capacity  4 free  5 status (text)  7 level ("RAID 5")
    #   poolTable    .2.2.2.1  2 id  3 capacity  4 free  5 status (0 ready, -1 warning, -2 not ready, -3 error)
    # The MIB has no link disk -> pool: the pool of a volume is in its name ("[Volume X, Pool 3]").
    $raids = @(); $pools = @()
    try {
        $sb = '1.3.6.1.4.1.24681.1.4.1.1.1'
        $s = Snmp-Walk $h $c $sb 2000
        function scol($table, $col) {
            $res = [ordered]@{}; $p = [regex]::Escape("$sb.$table.$col")
            foreach ($k in $s.Keys) { if ($k -match "^$p\.(\d+)$") { $res[$Matches[1]] = $s[$k] } }
            $res
        }
        $nId = scol '1.5.2.1' 2; $nSpare = scol '1.5.2.1' 7; $nCap = scol '1.5.2.1' 9
        foreach ($i in $nId.Keys) {
            $id = "$($nId[$i])"
            $d = @($disks | Where-Object { $_.idx -eq $id }) + @($disks | Where-Object { $_.idx -eq "$i" }) | Select-Object -First 1
            if (-not $d) { continue }
            $d.slot = $id
            if ($nCap[$i] -and [uint64]$nCap[$i] -gt 0) { $d.bytes = [uint64]$nCap[$i] }
            if ($null -ne $nSpare[$i] -and "$($nSpare[$i])" -ne '') { $d.spare = [int]$nSpare[$i] }
        }
        $rId = scol '2.1.2.1' 2; $rCap = scol '2.1.2.1' 3; $rFree = scol '2.1.2.1' 4; $rStat = scol '2.1.2.1' 5; $rLvl = scol '2.1.2.1' 7
        foreach ($i in $rId.Keys) {
            $raids += [ordered]@{ id = "$($rId[$i])"; level = "$($rLvl[$i])"; status = "$($rStat[$i])"
                                  total = $rCap[$i]; free = $rFree[$i] }
        }
        $plId = scol '2.2.2.1' 2; $pCap = scol '2.2.2.1' 3; $pFree = scol '2.2.2.1' 4; $pStat = scol '2.2.2.1' 5
        foreach ($i in $plId.Keys) {
            $t = $pCap[$i]; $f = $pFree[$i]
            $pools += [ordered]@{ id = "$($plId[$i])"; status = $pStat[$i]; total = $t; free = $f
                                  used = if ($null -ne $t -and $null -ne $f) { [uint64]$t - [uint64]$f } else { $null } }
        }
    } catch { }
    $slotsFree = @($disks | Where-Object { $_.empty -eq 1 }).Count
    $spares = @($disks | Where-Object { $_.spare -eq 1 }).Count
    $fans = @()
    $fDescr = col 15 2; $fSpeed = col 15 3
    foreach ($i in $fDescr.Keys) { $fans += [ordered]@{ idx = "$i"; descr = "$($fDescr[$i])"; rpm = (Get-Number $fSpeed[$i]) } }
    # Memory and temperatures: on QTS 5 the QNAP agent serves them with a "pass" script that answers only a direct GET,
    # not the table walk (seen on Macerata, TS-X32U QTS 5.1). Asked directly: legacy MIB, then its "Ex" copy (24681.1.3),
    # then the new QNAP MIB 55062 (QTS 5).
    $direct = @{}
    try {
        $direct = Snmp-Get $h $c @("$base.2.0", "$base.3.0", "$base.5.0", "$base.6.0",
                                   '1.3.6.1.4.1.24681.1.3.2.0', '1.3.6.1.4.1.24681.1.3.3.0', '1.3.6.1.4.1.24681.1.3.5.0',
                                   '1.3.6.1.4.1.24681.1.3.6.0', '1.3.6.1.4.1.55062.1.12.10.0', '1.3.6.1.4.1.55062.1.12.11.0',
                                   '1.3.6.1.4.1.55062.1.12.13.0', '1.3.6.1.4.1.55062.1.12.14.0')
    } catch { }
    function first-of($oids) {
        foreach ($o in $oids) { $v = if ($w.Contains($o)) { $w[$o] } else { $direct[$o] }; if ("$v".Trim()) { return "$v" } }
        $null
    }
    $tot = first-of @("$base.2.0", '1.3.6.1.4.1.24681.1.3.2.0', '1.3.6.1.4.1.55062.1.12.13.0')
    $free = first-of @("$base.3.0", '1.3.6.1.4.1.24681.1.3.3.0', '1.3.6.1.4.1.55062.1.12.14.0')
    $tCpu = first-of @("$base.5.0", '1.3.6.1.4.1.24681.1.3.5.0', '1.3.6.1.4.1.55062.1.12.10.0')
    $tSys = first-of @("$base.6.0", '1.3.6.1.4.1.24681.1.3.6.0', '1.3.6.1.4.1.55062.1.12.11.0')
    # "15.5 GB" style strings (legacy) or plain numbers in the same unit (new MIB): the ratio is what matters
    $totN = Get-Bytes $tot; $freeN = Get-Bytes $free
    if (-not $totN) { $totN = Get-Number $tot; $freeN = Get-Number $free }
    $memPused = if ($totN -gt 0 -and $null -ne $freeN) { [math]::Round((1 - $freeN / $totN) * 100, 1) } else { $null }
    if ($null -eq $memPused) {
        # HOST-RESOURCES-MIB hrStorageTable (Linux of the NAS): descr .3, size .5, used .6 (same units)
        try {
            $hr = Snmp-Walk $h $c '1.3.6.1.2.1.25.2.3.1'
            foreach ($k in $hr.Keys) {
                if ($k -match '^1\.3\.6\.1\.2\.1\.25\.2\.3\.1\.3\.(\d+)$' -and "$($hr[$k])" -match '(?i)physical memory|real memory') {
                    $size = [double]$hr["1.3.6.1.2.1.25.2.3.1.5.$($Matches[1])"]; $used = [double]$hr["1.3.6.1.2.1.25.2.3.1.6.$($Matches[1])"]
                    if ($size -gt 0) { $memPused = [math]::Round($used / $size * 100, 1) }
                }
            }
        } catch { }
    }
    [ordered]@{
        snmp = 1; name = "$($sys['1.3.6.1.2.1.1.5.0'])"; descr = "$($sys['1.3.6.1.2.1.1.1.0'])"
        uptime = if ($sys['1.3.6.1.2.1.1.3.0']) { [int64]($sys['1.3.6.1.2.1.1.3.0'] / 100) } else { $null }
        qnap = [int]($w.Count -gt 0)
        cpu = (Get-Number $w["$base.1.0"]); temp_cpu = (Get-Number $tCpu); temp_sys = (Get-Number $tSys)
        mem_pused = $memPused; mem_total = "$tot"
        disks = $disks; volumes = $vols; fans = $fans; raids = $raids; pools = $pools
        slots = $disks.Count; slots_used = $disks.Count - $slotsFree; slots_free = $slotsFree; spares = $spares
    }
}

# ---------------------------------------------------------------- OpenVPN
# The cameras often reach the video server through OpenVPN (the server is the OpenVPN server). A tunnel is a .ovpn
# file in the OpenVPN config folders: it is known even when it is down (a Wintun adapter disappears with its tunnel).
#   up = an openvpn.exe process runs with that file AND its adapter (dev-node or same name) is Up, when one is found.
function Get-OvpnOption([string[]]$lines, [string]$name) {
    foreach ($l in $lines) {
        if ($l -match "^\s*$name\s+(?:""([^""]+)""|(\S+))") { if ($Matches[1]) { return $Matches[1] } else { return $Matches[2] } }
    }
    $null
}

function Get-OvpnClients([string]$path) {
    # status file of a server: CLIENT_LIST lines (status-version 2/3) or the "Common Name,Real Address" block (version 1)
    $lines = @(Get-Content $path -ErrorAction Stop)
    $v2 = @($lines | Where-Object { $_ -match '^CLIENT_LIST[,\t]' }).Count
    if ($v2) { return $v2 }
    $in = $false; $n = 0
    foreach ($l in $lines) {
        if ($l -match '^Common Name,Real Address') { $in = $true; continue }
        if ($l -match '^ROUTING TABLE') { break }
        if ($in -and $l.Trim()) { $n++ }
    }
    $n
}

# Errors in the log of a tunnel: count of the last $minutes and the latest one (any age, among the last lines).
# Lines start with "2026-11-21 13:22:11" (OpenVPN 2.5+) or "Sat Nov 21 13:22:11 2026" (older versions).
$OVPN_ERROR = '(?i)(TLS Error|TLS handshake failed|AUTH_FAILED|VERIFY ERROR|certificate verify failed|Inactivity timeout|' +
              'Connection reset|fatal|error|failed|cannot|refused|unreachable)'
function Get-OvpnLogErrors([string]$path, [int]$minutes = 15) {
    $r = [ordered]@{ errors = -1; last_error = ''; last_error_age = -1 }
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return $r }
    $r.errors = 0
    $since = (Get-Date).AddMinutes(-$minutes); $now = Get-Date
    $en = [Globalization.CultureInfo]::InvariantCulture
    foreach ($l in @(Get-Content -LiteralPath $path -Tail 3000 -ErrorAction SilentlyContinue)) {
        if ($l -notmatch $OVPN_ERROR) { continue }
        $t = $null; $text = $l
        if ($l -match '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+(.*)$') {
            $t = [datetime]::ParseExact($Matches[1], 'yyyy-MM-dd HH:mm:ss', $en); $text = $Matches[2]
        } elseif ($l -match '^\w{3} (\w{3}) +(\d{1,2}) (\d{2}:\d{2}:\d{2}) (\d{4})\s+(.*)$') {
            $t = [datetime]::ParseExact("$($Matches[1]) $($Matches[2]) $($Matches[4]) $($Matches[3])", 'MMM d yyyy HH:mm:ss', $en)
            $text = $Matches[5]
        }
        if (-not $t) { continue }                  # no time: cannot say whether it is recent
        if ($t -ge $since) { $r.errors++ }
        $r.last_error = $(if ($text.Length -gt 200) { $text.Substring(0, 200) } else { $text })
        $r.last_error_age = [int][math]::Max(0, ($now - $t).TotalSeconds)
    }
    $r
}

function Get-Vpn {
    $base = Join-Path $env:ProgramFiles 'OpenVPN'
    $reg = Get-ItemProperty 'HKLM:\SOFTWARE\OpenVPN' -ErrorAction SilentlyContinue
    $dirs = @()
    foreach ($d in @($reg.config_dir, $reg.autostart_config_dir, (Join-Path $base 'config'), (Join-Path $base 'config-auto'))) {
        if ($d -and (Test-Path $d) -and ($dirs -notcontains $d)) { $dirs += $d }
    }
    # OpenVPN GUI profiles of the users (imported files)
    Get-ChildItem 'C:\Users\*\OpenVPN\config' -Directory -ErrorAction SilentlyContinue | ForEach-Object { $dirs += $_.FullName }

    $procs = @(Get-CimInstance Win32_Process -Filter "Name='openvpn.exe'" -ErrorAction SilentlyContinue)
    $adapters = @(Get-NetAdapter -IncludeHidden -ErrorAction SilentlyContinue)
    $tunnels = @(); $seen = @{}
    foreach ($d in $dirs) {
        foreach ($f in @(Get-ChildItem $d -Recurse -Depth 2 -File -Include '*.ovpn', '*.conf' -ErrorAction SilentlyContinue)) {
            $name = [IO.Path]::GetFileNameWithoutExtension($f.Name)
            if ($seen.ContainsKey($name.ToLower())) { continue }
            $seen[$name.ToLower()] = 1
            $lines = @(Get-Content $f.FullName -ErrorAction SilentlyContinue)
            $server = [bool](($lines -match '^\s*(server|server-bridge|mode\s+server)(\s|$)').Count)
            $proc = @($procs | Where-Object { $_.CommandLine -and $_.CommandLine -match [regex]::Escape($f.Name) })[0]
            $running = [bool]$proc
            $node = Get-OvpnOption $lines 'dev-node'
            $ad = $adapters | Where-Object { $_.Name -eq $(if ($node) { $node } else { $name }) } | Select-Object -First 1
            $up = $running -and (-not $ad -or "$($ad.Status)" -eq 'Up')
            $clients = -1; $statusAge = -1
            $st = Get-OvpnOption $lines 'status'
            if ($st) {
                if (-not [IO.Path]::IsPathRooted($st)) { $st = Join-Path $f.DirectoryName $st }
                if (Test-Path $st) {
                    $statusAge = [int]((Get-Date) - (Get-Item $st).LastWriteTime).TotalSeconds
                    # several tunnels can share one status file (same "status" line): a stopped tunnel would show the
                    # clients of a running one, so clients are read only while this tunnel runs
                    if ($running) { try { $clients = Get-OvpnClients $st } catch { } }
                }
            }
            # log, in this order:
            #  1. --log / --log-append of the running process: OpenVPN GUI starts openvpn.exe with
            #     --log "C:\Users\<user>\OpenVPN\log\<name>.log" (MACERATA PS, 2026-11-21), the service with log_dir
            #  2. "log" / "log-append" of the config
            #  3. the newest of log_dir\<name>.log (service) and C:\Users\*\OpenVPN\log\<name>.log (GUI)
            $log = $null
            if ($proc -and $proc.CommandLine -match '--log(?:-append)?\s+(?:"([^"]+)"|(\S+))') {
                $log = if ($Matches[1]) { $Matches[1] } else { $Matches[2] }
            }
            if (-not $log) { $log = Get-OvpnOption $lines 'log-append' }
            if (-not $log) { $log = Get-OvpnOption $lines 'log' }
            if ($log -and -not [IO.Path]::IsPathRooted($log)) { $log = Join-Path $f.DirectoryName $log }
            if (-not $log) {
                $logDir = if ($reg.log_dir) { $reg.log_dir } else { Join-Path $base 'log' }
                $cand = @(@(Join-Path $logDir "$name.log") + @(Get-ChildItem "C:\Users\*\OpenVPN\log\$name.log" -ErrorAction SilentlyContinue |
                          ForEach-Object { $_.FullName }) | Where-Object { Test-Path -LiteralPath $_ } |
                          Sort-Object { (Get-Item -LiteralPath $_).LastWriteTime } -Descending)
                $log = if ($cand) { $cand[0] } else { Join-Path $logDir "$name.log" }
            }
            # started by OpenVPN GUI = it runs only while that user is logged on (a reboot without logon = VPN down)
            $by = if (-not $proc) { '' } elseif ($proc.CommandLine -match 'IV_GUI_VER|--management\s+127\.0\.0\.1') { 'gui' } else { 'servizio' }
            $le = Get-OvpnLogErrors $log
            $tunnels += [ordered]@{
                name = $name; file = $f.FullName; mode = $(if ($server) { 'server' } else { 'client' })
                running = [int]$running; adapter = $(if ($ad) { $ad.Name } else { '' })
                adapter_status = $(if ($ad) { "$($ad.Status)" } else { '' }); up = [int]$up
                clients = $clients; status_age = $statusAge; started_by = $by
                log = $(if (Test-Path -LiteralPath $log) { $log } else { '' })
                errors = $le.errors; last_error = $le.last_error; last_error_age = $le.last_error_age
            }
        }
    }
    $services = @(Get-Service -Name 'OpenVPN*' -ErrorAction SilentlyContinue | ForEach-Object {
        [ordered]@{ name = $_.Name; display = $_.DisplayName; state = "$($_.Status)"; start = "$($_.StartType)" } })
    [ordered]@{ installed = [int]((Test-Path $base) -or ($tunnels.Count -gt 0)); tunnels = $tunnels; services = $services } |
        ConvertTo-Json -Depth 4 -Compress
}

function Test-Tcp([string]$h, [int]$port) {
    $c = New-Object Net.Sockets.TcpClient
    try { $ar = $c.BeginConnect($h, $port, $null, $null); $ok = $ar.AsyncWaitHandle.WaitOne(2000) -and $c.Connected; [int]$ok }
    catch { 0 } finally { $c.Close() }
}

function Get-Nas {
    if (-not ('Zbx.Disk' -as [type])) {
        $sig = '[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] ' +
               'public static extern bool GetDiskFreeSpaceEx(string dir, out ulong freeForUser, out ulong total, out ulong totalFree);'
        Add-Type -Namespace Zbx -Name Disk -MemberDefinition $sig
    }
    $cfg = Get-Config
    $community = $null
    $snmpFile = Join-Path $DIR 'snmp.bin'
    if (Test-Path $snmpFile) { $community = Read-Protected $snmpFile }
    # network paths used by Milestone (storages, archives) and by the Smart Client exports
    $shares = [ordered]@{}
    $infoFile = Join-Path $DIR 'info.json'
    if (Test-Path $infoFile) {
        $info = Get-Content $infoFile -Raw | ConvertFrom-Json
        foreach ($rec in $info.Srv.Rec) { foreach ($st in $rec.storages) {
            if ("$($st.path)" -like '\\*') { $shares["$($st.path)"] = 'storage' }
            foreach ($a in $st.archives) { if ("$($a.path)" -like '\\*') { $shares["$($a.path)"] = 'archivio' } }
        } }
    }
    Get-ChildItem 'C:\Users\*\AppData\Roaming\Milestone\Smart Client\UserSettings*.xml' -Force -ErrorAction SilentlyContinue | ForEach-Object {
        $m = Select-String -Path $_.FullName -Pattern 'ExportPath="([^"]+)"' | Select-Object -First 1
        if ($m) {
            $p = $m.Matches[0].Groups[1].Value
            if ($p -match '^([A-Za-z]):(.*)$') {        # mapped drive -> network path (persistent mappings)
                $letter = $Matches[1].ToUpper(); $rest = $Matches[2]
                foreach ($k in @("HKCU:\Network\$letter") + @(Get-ChildItem 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue | ForEach-Object { "Registry::$($_.Name)\Network\$letter" })) {
                    $remote = (Get-ItemProperty -Path $k -Name RemotePath -ErrorAction SilentlyContinue).RemotePath
                    if ($remote) { $p = $remote.TrimEnd('\') + $rest; break }
                }
            }
            if ($p -like '\\*' -and -not $shares.Contains($p)) { $shares[$p] = 'esportazioni' }
        }
    }
    # network drives mapped by the users (e.g. Z: -> \\NAS\video): persistent mappings of the loaded user hives.
    # A service does not see the drive letters of a logon session, so the letter is read from the registry.
    foreach ($u in @(Get-ChildItem 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue)) {
        foreach ($k in @(Get-ChildItem "Registry::$($u.Name)\Network" -ErrorAction SilentlyContinue)) {
            $remote = "$((Get-ItemProperty -Path $k.PSPath -Name RemotePath -ErrorAction SilentlyContinue).RemotePath)".TrimEnd('\')
            if ($remote -notlike '\\*') { continue }
            $drive = "unit$([char]0xE0) $($k.PSChildName.ToUpper()):"
            if (-not $shares.Contains($remote)) { $shares[$remote] = $drive }
            elseif ($shares[$remote] -notlike "*$drive*") { $shares[$remote] = "$($shares[$remote]), $drive" }
        }
    }
    $names = [ordered]@{}
    foreach ($s in $shares.Keys) { if ($s -match '^\\\\([^\\]+)') { $names[$Matches[1].ToUpper()] = $true } }
    foreach ($h in @($cfg.nas_hosts)) { if ("$h".Trim()) { $names["$h".Trim().ToUpper()] = $true } }
    # the same NAS can be reached by name and by IP (e.g. archive \\NRPA065\..., exports \\10.127.11.250\...):
    # one NAS per IP address, named with the host name when there is one
    $byIp = [ordered]@{}; $canon = @{}; $ipOf = @{}
    foreach ($h in $names.Keys) {
        # resolved ONCE, lowest address first: a NAS with two network cards answers with either address in turn
        # (L'AQUILA NRPA084, 2026-11-22); a second lookup giving the other one left the NAS without a name and the
        # whole collection failed ("ContainsKey: key cannot be null")
        $ip = ''
        try {
            $ip = (@([Net.Dns]::GetHostAddresses($h) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } |
                     ForEach-Object { $_.IPAddressToString }) | Sort-Object { [version]$_ } | Select-Object -First 1)
        } catch { }
        $ip = "$ip"; $ipOf[$h] = $ip
        $k = if ($ip) { $ip } else { $h }
        $isIp = $h -match '^\d+\.\d+\.\d+\.\d+$'
        if (-not $byIp.Contains($k) -or ($byIp[$k].isIp -and -not $isIp)) { $byIp[$k] = @{ name = $h; ip = $ip; isIp = $isIp } }
    }
    foreach ($h in $names.Keys) {
        $k = if ($ipOf[$h]) { $ipOf[$h] } else { $h }
        $canon[$h] = if ($byIp.Contains($k)) { $byIp[$k].name } else { $h }
    }
    # a NAS with two network cards (two IPs): an entry known only by IP whose network name (reverse lookup,
    # NetBIOS/DNS) is the name of another entry is the same NAS -> one entry, extra IPs listed, SNMP asked once
    $extraIps = @{}
    foreach ($k in @($byIp.Keys)) {
        $e = $byIp[$k]
        if (-not $e.isIp) { continue }
        $rev = ''
        try { $rev = ([Net.Dns]::GetHostEntry($e.ip).HostName -split '\.')[0].ToUpper() } catch { }
        $same = @($byIp.Values | Where-Object { -not $_.isIp -and $_.name -eq $rev }) | Select-Object -First 1
        if ($rev -and $same) {
            $extraIps[$same.name] = @($extraIps[$same.name]) + @($e.ip) | Where-Object { $_ }
            foreach ($h in @($canon.Keys)) { if ($canon[$h] -eq $e.name) { $canon[$h] = $same.name } }
            $byIp.Remove($k)
        }
    }

    $shareOut = @(foreach ($s in $shares.Keys) {
        $free = [uint64]0; $total = [uint64]0; $tf = [uint64]0
        $ok = [Zbx.Disk]::GetDiskFreeSpaceEx($s.TrimEnd('\') + '\', [ref]$free, [ref]$total, [ref]$tf)
        # id: the path without separators, usable in Zabbix keys and JSONPath filters (no backslashes)
        [ordered]@{ id = ($s -replace '[^A-Za-z0-9]+', '_').Trim('_'); path = $s
                    host = if ($s -match '^\\\\([^\\]+)') { $canon[$Matches[1].ToUpper()] } else { '' }; use = $shares[$s]
                    ok = [int]$ok; total = if ($ok) { $total } else { $null }; free = if ($ok) { $free } else { $null }
                    pfree = if ($ok -and $total -gt 0) { [math]::Round($free / $total * 100, 1) } else { $null } }
    })
    $nasOut = @(foreach ($e in $byIp.Values) {
        $h = $e.name; $ip = $e.ip
        $n = [ordered]@{ host = $h; ip = $ip; smb = (Test-Tcp $h 445); snmp = -1 }   # snmp -1 = no community configured
        if ($extraIps[$h]) { $n.extra_ips = @($extraIps[$h]) }
        if ($community) {
            try {
                $target = $(if ($ip) { $ip } else { $h })
                $n.snmp_port = Find-SnmpPort $target $community
                foreach ($kv in (Get-QnapHealth $target $community).GetEnumerator()) { $n[$kv.Key] = $kv.Value }
            }
            catch { $n.snmp = 0; $n.snmp_error = $_.Exception.Message }
        }
        $n
    })
    # a NAS with two network cards answers on two IPs with the same SNMP name: one NAS, the other IPs listed
    $merged = @(); $alias = @{}; $bySnmp = @{}
    foreach ($n in $nasOut) {
        $key = if ($n.snmp -eq 1 -and $n.name) { "$($n.name)".ToUpper() } else { $null }
        if ($key -and $bySnmp.ContainsKey($key)) {
            $keep = $bySnmp[$key]
            $keep.ips = @($keep.ips) + @($n.ip)
            if ($n.smb -eq 1) { $keep.smb = 1 }
            if ($keep.host -match '^\d+\.\d+\.\d+\.\d+$' -and $n.host -notmatch '^\d+\.\d+\.\d+\.\d+$') {
                $alias[$keep.host] = $n.host; $keep.host = $n.host          # prefer the name to the IP
            } else { $alias[$n.host] = $keep.host }
        } else {
            $n.ips = @(@($n.ip) + @($n.extra_ips) | Where-Object { $_ })
            if ($key) { $bySnmp[$key] = $n }
            $merged += $n
        }
    }
    foreach ($s in $shareOut) { if ($s.host -and $alias.ContainsKey($s.host)) { $s.host = $alias[$s.host] } }
    [ordered]@{ nas = $merged; shares = $shareOut } | ConvertTo-Json -Depth 6 -Compress
}

# ---------------------------------------------------------------- stopped services (every 5 minutes)
# Windows services with automatic (or delayed) start that are not running, without the "trigger start" ones:
# the same services the template "Windows by Zabbix agent active" alarms on (it excludes trigger-start services).
# The template "Milestone Riepilogo" filters them with {$SERVICE.NAME.NOT_MATCHES} and lists the names.
function Get-StoppedServices {
    $out = @(foreach ($s in @(Get-CimInstance Win32_Service -Filter "StartMode='Auto' AND State<>'Running'")) {
        if (Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($s.Name)\TriggerInfo") { continue }
        [ordered]@{ name = "$($s.Name)"; display = "$($s.DisplayName)" }
    })
    ConvertTo-Json -InputObject $out -Compress
}

# ---------------------------------------------------------------- deletions (every 10 minutes)
# The Recording Server writes every deleted table (one hour of one camera) in Logs\Database_*.log with the reason:
#   ... - Deleting table <cameraId>_<KIND>_<yyyy-MM-dd_HH-mm-ss> in <bank path> begun.Maximum time limit(7 days) reached for bank.
# "Maximum time limit" = normal end of the retention. Any other reason (size limit, disk full...) = recordings
# deleted BEFORE the retention time: for the user's work every camera must keep everything (2026-11-21).
function Get-Deletions {
    $hours = 24
    $since = (Get-Date).AddHours(-$hours)
    $logDir = if ($env:ZBXMS_RSLOG) { $env:ZBXMS_RSLOG } else { 'C:\ProgramData\Milestone\XProtect Recording Server\Logs' }   # env: tests only
    $cams = @{}; $banks = @{}
    $infoFile = Join-Path $DIR 'info.json'
    if (Test-Path $infoFile) {
        $info = Get-Content $infoFile -Raw | ConvertFrom-Json
        foreach ($c in $info.Hw.Cam) { $cams["$($c.id)".ToLower()] = "$($c.displayName)" }
        foreach ($rec in $info.Srv.Rec) { foreach ($st in $rec.storages) {
            $banks[(Join-Path $st.path $st.id).TrimEnd('\').ToLower()] = "$($st.displayName)"
            foreach ($a in $st.archives) { if ($a.path) { $banks["$($a.path)".TrimEnd('\').ToLower()] = "$($a.displayName)" } }
        } }
    }
    $re = 'Deleting table ([0-9a-fA-F-]{36})_\S+ in (.+?) begun\.\s*(.*)$'
    $normal = 0; $early = 0; $last = $null; $reasons = @{}
    $files = @(Get-ChildItem $logDir -Filter 'Database_*.log' -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -gt $since })
    foreach ($m in @($files | Select-String -Pattern $re)) {
        $t = $null
        try { $t = [datetime]::ParseExact($m.Line.Substring(0, 19), 'yyyy-MM-dd HH:mm:ss', $null) } catch { continue }
        if ($t -lt $since) { continue }
        $g = $m.Matches[0].Groups
        $reason = $g[3].Value.Trim()
        if ($reason -match '^Maximum time limit') { $normal++; continue }
        $early++
        $key = ($reason -replace '\([^)]*\)', '(...)')
        $reasons[$key] = 1 + [int]$reasons[$key]
        $bank = $g[2].Value.TrimEnd('\').ToLower()
        $storage = if ($banks.ContainsKey($bank)) { $banks[$bank] } else { $g[2].Value }
        $cam = $g[1].Value.ToLower()
        $last = [ordered]@{ time = (To-Unix $t); camera = $(if ($cams.ContainsKey($cam)) { $cams[$cam] } else { $cam })
                            storage = $storage; reason = $reason
                            text = ("{0:dd/MM HH:mm} {1} - {2}: {3}" -f $t, $(if ($cams.ContainsKey($cam)) { $cams[$cam] } else { $cam }), $storage, $reason) }
    }
    [ordered]@{ hours = $hours; files = $files.Count; normal = $normal; early = $early
                last_early = $(if ($last) { $last.text } else { '' }); last = $last; reasons = $reasons } | ConvertTo-Json -Depth 4 -Compress
}

# ---------------------------------------------------------------- main
try {
    switch ($Mode) {
        'info'    { Get-InfoAny }
        'status'  { Get-Status }
        'license' { if ((Get-Config).api -eq 'legacy') { Get-LicenseLegacy } else { Get-License } }
        'retention' { Get-Retention }
        'retention-build' {
            try { Build-Retention; Remove-Item -LiteralPath $RET_ERR -Force -ErrorAction SilentlyContinue }
            catch { Set-Content -LiteralPath $RET_ERR -Value ($_.Exception.Message -replace '\s+', ' ') -Encoding UTF8; throw }
            finally { Remove-Item -LiteralPath $RET_LOCK -Force -ErrorAction SilentlyContinue }
        }
        'nas'     { Get-Nas }
        'vpn'     { Get-Vpn }
        'services' { Get-StoppedServices }
        'deletions' { Get-Deletions }
    }
} catch {
    # one line, no secrets: the template turns "ERROR:" into an item error
    $msg = 'ERROR: ' + ($_.Exception.Message -replace '\s+', ' ')
    if ($_.Exception -is [Net.WebException] -and $script:LastHttp) { $msg += " [$script:LastHttp]" }
    $msg
}
