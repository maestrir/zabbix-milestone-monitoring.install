<#
.SYNOPSIS
  Started by MilestoneMonitor-<version>-setup.exe (or by hand): first installation or update of the Milestone
  monitoring on this video server, in a console window that stays open at the end.

.DESCRIPTION
  - monitoring not installed           -> Install-MilestoneMonitor.ps1 (asks the questions)
  - monitoring already installed       -> choice: 1 = update (default, no questions), 2 = reinstall (asks again)
#>
[CmdletBinding()]
param([string] $Channel)

$ErrorActionPreference = 'Stop'
$PKG = $PSScriptRoot
# package files extracted from a zip downloaded with a browser keep the "internet" mark: RemoteSigned would block them
Get-ChildItem $PKG -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$DATA = Join-Path $env:ProgramData 'zbx-milestone'
try { $Host.UI.RawUI.WindowTitle = 'Monitoraggio Milestone - installazione' } catch { }
$version = (Get-Content (Join-Path $PKG 'VERSION') -Raw).Trim()
Write-Host "Monitoraggio Milestone - pacchetto $version" -ForegroundColor Green
Write-Host ''

try {
    $installed = (Get-Service 'Zabbix Agent 2' -ErrorAction SilentlyContinue) -and (Test-Path (Join-Path $DATA 'config.json'))
    $mode = 'install'
    if ($installed) {
        $old = if (Test-Path "$DATA\package_version.txt") { (Get-Content "$DATA\package_version.txt" -Raw).Trim() } else { '?' }
        Write-Host "Il monitoraggio e' gia' installato (pacchetto $old)." -ForegroundColor Yellow
        Write-Host '  1 = aggiorna (consigliato): tiene tutte le impostazioni, nessuna domanda'
        Write-Host '  2 = reinstalla: rifa'' tutte le domande (server Zabbix, accesso Milestone, NAS, sito)'
        $c = Read-Host 'Scelta [1]'
        $mode = if ($c.Trim() -eq '2') { 'install' } else { 'update' }
    }
    if ($mode -eq 'update') { & (Join-Path $PKG 'Aggiorna-MilestoneMonitor.ps1') }
    elseif ($Channel) { & (Join-Path $PKG 'Install-MilestoneMonitor.ps1') -Channel $Channel }
    else { & (Join-Path $PKG 'Install-MilestoneMonitor.ps1') }
} catch {
    Write-Host ''
    Write-Host "ERRORE: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log: $DATA\install.log" -ForegroundColor Red
}
Write-Host ''
Read-Host 'Premi Invio per chiudere'
