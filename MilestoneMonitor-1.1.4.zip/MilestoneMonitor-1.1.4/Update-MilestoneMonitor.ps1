<#
.SYNOPSIS
  Automatic update of the Milestone monitoring on a video server (signed packages from GitHub).

.DESCRIPTION
  Daily scheduled task "MilestoneMonitor-Aggiornamento" (SYSTEM, random hour 01-05) runs:
      Update-MilestoneMonitor.ps1                 check the channel and install a newer signed version
      Update-MilestoneMonitor.ps1 -Force          reinstall the version of the channel even if not newer
  Installer / Aggiorna run once:
      Update-MilestoneMonitor.ps1 -Register [-Channel stable|test]
          copies this script and the public key to C:\Program Files\MilestoneMonitor and creates the task.

  Steps of an update:
    1. download manifest.json + manifest.sig of the channel (public repository, branch = channel)
    2. check the RSA signature of the manifest with update_key.xml: an unsigned or altered manifest is refused
    3. if the version is newer: download the zip, check size and SHA256 written in the signed manifest
    4. save the current scripts (backup), run Aggiorna-MilestoneMonitor.ps1 of the new package
    5. check: agent running, scripts readable, agent configuration valid; otherwise put the backup back (rollback)
  Result for Zabbix (item mxp.update): C:\ProgramData\zbx-milestone\update_status.json ; log: update.log there.
#>
[CmdletBinding()]
param(
    [switch] $Register,
    [string] $Channel,
    [switch] $Force
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$REPO_RAW = 'https://raw.githubusercontent.com/maestrir/zabbix-milestone-monitoring.install'
$TASK = 'MilestoneMonitor-Aggiornamento'
$HOME_DIR = Join-Path $env:ProgramFiles 'MilestoneMonitor'      # only Administrators/SYSTEM can write here
$DATA = Join-Path $env:ProgramData 'zbx-milestone'              # readable by the agent (status file)
$AGENT_DIR = 'C:\Program Files\Zabbix Agent 2'
$STATUS = Join-Path $DATA 'update_status.json'
$LOG = Join-Path $DATA 'update.log'
$SETTINGS = Join-Path $HOME_DIR 'update.json'

function Write-Log([string]$m) {
    $line = "{0:s} {1}" -f (Get-Date), $m
    Write-Host $line
    Add-Content -Path $LOG -Value $line -ErrorAction SilentlyContinue
}

function Get-PackageVersion {
    $f = Join-Path $DATA 'package_version.txt'
    if (Test-Path $f) { (Get-Content $f -Raw).Trim() } else { '0.0.0' }
}

function Get-Channel {
    $c = 'stable'
    if (Test-Path $SETTINGS) {
        try { $v = (Get-Content $SETTINGS -Raw | ConvertFrom-Json).channel; if ($v) { $c = $v } } catch { }
    }
    if ($c -notmatch '^[a-z0-9-]{1,20}$') { $c = 'stable' }
    $c
}

# status for Zabbix: UTF-8 without BOM, one line
function Save-Status([string]$result, [string]$message, [string]$latest = '') {
    $s = [ordered]@{
        version    = Get-PackageVersion
        channel    = Get-Channel
        result     = $result          # ok | aggiornato | errore | ripristinato | installato
        message    = if ($message.Length -gt 250) { $message.Substring(0, 250) } else { $message }
        latest     = $latest
        last_check = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    }
    [IO.File]::WriteAllText($STATUS, ($s | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false))
}

# update.json may name another source ("url"): a mirror, or a local folder (file:///...) for the laboratory tests
function Get-BaseUrl([string]$channel) {
    $u = $null
    if (Test-Path $SETTINGS) { try { $u = (Get-Content $SETTINGS -Raw | ConvertFrom-Json).url } catch { } }
    if ($u) { "$($u.TrimEnd('/'))/$channel" } else { "$REPO_RAW/$channel" }
}

function Compare-Version([string]$a, [string]$b) {
    ([version]$a).CompareTo([version]$b)
}

function Test-Signature([byte[]]$data, [string]$sigText) {
    $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
    $rsa.PersistKeyInCsp = $false
    $rsa.FromXmlString((Get-Content (Join-Path $HOME_DIR 'update_key.xml') -Raw))
    $sig = [Convert]::FromBase64String($sigText.Trim())
    $rsa.VerifyData($data, $sig, [Security.Cryptography.HashAlgorithmName]::SHA256,
        [Security.Cryptography.RSASignaturePadding]::Pkcs1)
}

# 3 attempts, 5 minutes apart: a short internet or GitHub outage must not give an alarm in Zabbix
function Get-Bytes([string]$url) {
    for ($i = 1; ; $i++) {
        try {
            $wc = New-Object Net.WebClient
            $wc.Headers['Cache-Control'] = 'no-cache'
            if ($url -like 'file:*') { return , $wc.DownloadData($url) }
            return , $wc.DownloadData($url + '?t=' + [DateTime]::UtcNow.Ticks)     # skip caches on the way
        } catch {
            if ($i -ge 3) { throw }
            Write-Log "Download non riuscito ($($_.Exception.Message)), nuovo tentativo fra 5 minuti"
            Start-Sleep 300
        }
    }
}

# files replaced by an update: saved before, put back on rollback
function Get-ManagedFiles {
    @("$AGENT_DIR\scripts\milestone_collect.ps1", "$AGENT_DIR\scripts\milestone_export_status.ps1",
      "$AGENT_DIR\zabbix_agent2.d\milestone_monitor.conf", (Join-Path $DATA 'package_version.txt'),
      (Join-Path $HOME_DIR 'Update-MilestoneMonitor.ps1'), (Join-Path $HOME_DIR 'update_key.xml'))
}

function Test-Installation {
    $problems = @()
    foreach ($f in "$AGENT_DIR\scripts\milestone_collect.ps1", "$AGENT_DIR\scripts\milestone_export_status.ps1") {
        $err = $null
        [Management.Automation.Language.Parser]::ParseFile($f, [ref]$null, [ref]$err) | Out-Null
        if ($err -and $err.Count) { $problems += "script non valido: $(Split-Path $f -Leaf)" }
    }
    $exe = Join-Path $AGENT_DIR 'zabbix_agent2.exe'
    $conf = Join-Path $AGENT_DIR 'zabbix_agent2.conf'
    if ((Test-Path $exe) -and (Test-Path $conf)) {
        & $exe -c $conf -T *> $null
        if ($LASTEXITCODE -ne 0) { $problems += 'configurazione agent non valida' }
    }
    Start-Sleep 20
    if ((Get-Service 'Zabbix Agent 2').Status -ne 'Running') { $problems += 'agent Zabbix fermo' }
    $problems
}

# ---------------------------------------------------------------- -Register: install this script and the task
if ($Register) {
    New-Item -ItemType Directory -Force $HOME_DIR, $DATA | Out-Null
    $src = $PSScriptRoot
    if ($src -ne $HOME_DIR) {
        Copy-Item (Join-Path $src 'Update-MilestoneMonitor.ps1'), (Join-Path $src 'update_key.xml') $HOME_DIR -Force
    }
    if ($Channel -or -not (Test-Path $SETTINGS)) {
        $st = [ordered]@{ channel = 'stable' }
        if (Test-Path $SETTINGS) {      # keep the other settings (url)
            try { (Get-Content $SETTINGS -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $st[$_.Name] = $_.Value } } catch { }
        }
        if ($Channel) { $st.channel = $Channel.ToLower() }
        $st | ConvertTo-Json | Set-Content $SETTINGS -Encoding ASCII
    }
    # keep the hour of an existing task, otherwise a random one between 01:00 and 05:00 (servers do not all
    # download at the same minute)
    $old = Get-ScheduledTask -TaskName $TASK -ErrorAction SilentlyContinue
    $at = $null
    if ($old) { try { $at = [datetime]$old.Triggers[0].StartBoundary } catch { } }
    if (-not $at) { $at = (Get-Date).Date.AddHours(1).AddMinutes((Get-Random -Minimum 0 -Maximum 240)) }
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument (
        "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$HOME_DIR\Update-MilestoneMonitor.ps1`"")
    $trigger = New-ScheduledTaskTrigger -Daily -At $at
    $set = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 1) `
        -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $TASK -Action $action -Trigger $trigger -Settings $set -User 'SYSTEM' `
        -RunLevel Highest -Description 'Aggiornamento automatico del monitoraggio Milestone (pacchetti firmati).' `
        -Force | Out-Null
    if (-not (Test-Path $STATUS)) { Save-Status 'installato' 'aggiornamento automatico attivo' }
    # the log is read by Zabbix (log[] item): it must exist before the first nightly check
    Write-Log ("Aggiornamento automatico attivo: pacchetto {0}, canale {1}" -f (Get-PackageVersion), (Get-Channel)) | Out-Null
    Write-Host ("Aggiornamento automatico attivo: canale {0}, ogni giorno alle {1:HH:mm}" -f (Get-Channel), $at) -ForegroundColor Green
    return
}

# ---------------------------------------------------------------- update
$channel = Get-Channel
$current = Get-PackageVersion
$latest = ''
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $base = Get-BaseUrl $channel
    $manBytes = Get-Bytes "$base/manifest.json"
    $sigText = [Text.Encoding]::ASCII.GetString((Get-Bytes "$base/manifest.sig"))
    if (-not (Test-Signature $manBytes $sigText)) { throw 'firma del manifest NON valida: aggiornamento rifiutato' }
    $man = [Text.Encoding]::UTF8.GetString($manBytes) | ConvertFrom-Json
    if ($man.channel -ne $channel) { throw "manifest del canale $($man.channel), atteso $channel" }
    if ($man.zip -notmatch '^[A-Za-z0-9._-]+\.zip$' -or $man.version -notmatch '^\d+(\.\d+){1,3}$') { throw 'manifest non valido' }
    $latest = $man.version

    if (-not $Force -and (Compare-Version $latest $current) -le 0) {
        # one line per check: the log exists from the first night and Zabbix shows that the check runs
        Write-Log "Controllo: installata $current, pubblicata $latest (canale $channel), niente da fare"
        Save-Status 'ok' "nessuna versione nuova (canale $channel)" $latest
        return
    }

    Write-Log "Aggiornamento $current -> $latest (canale $channel)"
    $work = Join-Path $HOME_DIR 'updates'
    if (Test-Path $work) { Remove-Item $work -Recurse -Force }
    New-Item -ItemType Directory -Force $work | Out-Null
    $zip = Join-Path $work $man.zip
    [IO.File]::WriteAllBytes($zip, (Get-Bytes "$base/$($man.zip)"))
    if ((Get-Item $zip).Length -ne [long]$man.size) { throw 'dimensione del pacchetto diversa dal manifest' }
    if ((Get-FileHash $zip -Algorithm SHA256).Hash -ne ([string]$man.sha256).ToUpper()) { throw 'SHA256 del pacchetto diverso dal manifest' }
    Expand-Archive $zip -DestinationPath $work -Force
    $pkg = Get-ChildItem $work -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'Aggiorna-MilestoneMonitor.ps1') } |
        Select-Object -First 1
    if (-not $pkg) { throw 'pacchetto senza Aggiorna-MilestoneMonitor.ps1' }

    # backup of the current files
    $bak = Join-Path $HOME_DIR 'backup'
    if (Test-Path $bak) { Remove-Item $bak -Recurse -Force }
    New-Item -ItemType Directory -Force $bak | Out-Null
    $saved = @()
    foreach ($f in Get-ManagedFiles) {
        if (Test-Path $f) {
            $name = ($f -replace '[:\\ ]', '_')
            Copy-Item $f (Join-Path $bak $name) -Force
            $saved += [pscustomobject]@{ path = $f; copy = $name }
        }
    }
    $saved | ConvertTo-Json | Set-Content (Join-Path $bak 'files.json') -Encoding UTF8

    try {
        # output kept as text in the log (a *>> redirection would write UTF-16 into the UTF-8 log)
        $out = & (Join-Path $pkg.FullName 'Aggiorna-MilestoneMonitor.ps1') -Auto *>&1 | Out-String
        Add-Content -Path $LOG -Value ($out.Trim())
        $problems = @(Test-Installation)
    } catch { $problems = @("errore durante l'aggiornamento: $($_.Exception.Message)") }

    if ($problems.Count) {
        Write-Log ("Problemi dopo l'aggiornamento: " + ($problems -join '; ') + ' -> ripristino')
        Stop-Service 'Zabbix Agent 2' -ErrorAction SilentlyContinue
        foreach ($s in $saved) { Copy-Item (Join-Path $bak $s.copy) $s.path -Force }
        Start-Service 'Zabbix Agent 2' -ErrorAction SilentlyContinue
        Save-Status 'ripristinato' ("versione $latest non installata, tornato a $current" + ': ' + ($problems -join '; ')) $latest
        return
    }
    Write-Log "Aggiornato a $(Get-PackageVersion)"
    Save-Status 'aggiornato' "aggiornato da $current a $(Get-PackageVersion)" $latest
} catch {
    $m = $_.Exception.Message
    if ($_.Exception.InnerException) { $m += ' (' + $_.Exception.InnerException.Message + ')' }
    Write-Log "ERRORE: $m"
    Save-Status 'errore' $m $latest
}
