<#
.SYNOPSIS
  Updates the Milestone monitoring of a video server that is already installed: replaces only the scripts and the
  agent configuration of the package, restarts the agent and prints the final report. No questions.

.DESCRIPTION
  Run as Administrator from the folder of the NEW package:
      powershell -ExecutionPolicy Bypass -File .\Aggiorna-MilestoneMonitor.ps1
  Kept as they are: Zabbix server name, PSK, host name, Milestone access (Windows / basic user), agent account and its
  password, SNMP community, NAS list, site data. The Zabbix agent itself is not reinstalled.
  For a first installation, or to change those settings, use Install-MilestoneMonitor.ps1.
  It also installs / refreshes the automatic update (Update-MilestoneMonitor.ps1, daily task).
  Log: C:\ProgramData\zbx-milestone\install.log ; report: C:\ProgramData\zbx-milestone\install-report.txt
#>
[CmdletBinding()]
param(
    # used by Update-MilestoneMonitor.ps1 (SYSTEM, automatic update): no final report, because the report
    # tests Milestone as the user running it and SYSTEM may not be in a Milestone role
    [switch] $Auto
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$PKG = $PSScriptRoot
$DATA = Join-Path $env:ProgramData 'zbx-milestone'
$AGENT_DIR = 'C:\Program Files\Zabbix Agent 2'
$LOG = Join-Path $DATA 'install.log'

function Write-Step([string]$m, [string]$color = 'Cyan') {
    Write-Host $m -ForegroundColor $color
    Add-Content -Path $LOG -Value ("{0:s} [aggiorna] {1}" -f (Get-Date), $m)
}

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Avviare come Amministratore.' }
foreach ($f in 'milestone_collect.ps1', 'milestone_export_status.ps1', 'milestone_monitor.conf', 'VERSION', 'Report-MilestoneMonitor.ps1',
           'Update-MilestoneMonitor.ps1', 'update_key.xml') {
    if (-not (Test-Path (Join-Path $PKG $f))) { throw "Manca il file $f nella cartella del pacchetto." }
}
if (-not (Get-Service 'Zabbix Agent 2' -ErrorAction SilentlyContinue) -or -not (Test-Path (Join-Path $DATA 'config.json'))) {
    throw 'Il monitoraggio non e'' installato su questo server: usare Install-MilestoneMonitor.ps1.'
}

$new = (Get-Content (Join-Path $PKG 'VERSION') -Raw).Trim()
$old = if (Test-Path "$DATA\package_version.txt") { (Get-Content "$DATA\package_version.txt" -Raw).Trim() } else { '?' }
Write-Step "Aggiornamento monitoraggio Milestone: $old -> $new" 'Green'

# the new package may need settings added after the first installation
$cfg = Get-Content "$DATA\config.json" -Raw | ConvertFrom-Json
if (-not $cfg.PSObject.Properties['api']) {
    $apiMode = 'rest'
    try { $wk = Invoke-WebRequest -UseBasicParsing -Uri ($cfg.mgm_url.TrimEnd('/') + '/api/.well-known/uris') -TimeoutSec 15 } catch { $wk = $null }
    if (-not $wk -or $wk.StatusCode -ne 200) { $apiMode = 'legacy' }
    $cfg | Add-Member -NotePropertyName api -NotePropertyValue $apiMode
    $cfg | ConvertTo-Json | Set-Content "$DATA\config.json" -Encoding UTF8
    Write-Step "Configurazione: aggiunta la modalita' $apiMode"
}

Write-Step 'Fermo l''agent e sostituisco script e configurazione'
Stop-Service 'Zabbix Agent 2'
New-Item -ItemType Directory -Force "$AGENT_DIR\scripts", "$AGENT_DIR\zabbix_agent2.d" | Out-Null
Copy-Item (Join-Path $PKG 'milestone_collect.ps1'), (Join-Path $PKG 'milestone_export_status.ps1') "$AGENT_DIR\scripts\" -Force
Copy-Item (Join-Path $PKG 'milestone_monitor.conf') "$AGENT_DIR\zabbix_agent2.d\" -Force
Remove-Item "$AGENT_DIR\zabbix_agent2.d\milestone_export.conf" -Force -ErrorAction SilentlyContinue   # old name
Remove-Item (Join-Path $DATA 'info.json'), (Join-Path $DATA 'token.bin') -Force -ErrorAction SilentlyContinue   # rebuilt at once
Set-Content (Join-Path $DATA 'package_version.txt') $new -Encoding ASCII
Start-Service 'Zabbix Agent 2'
Write-Step ("Agent riavviato: {0}" -f (Get-Service 'Zabbix Agent 2').Status)

Write-Step 'Aggiornamento automatico (attivita'' pianificata giornaliera)'
& (Join-Path $PKG 'Update-MilestoneMonitor.ps1') -Register

if (-not $Auto) { & (Join-Path $PKG 'Report-MilestoneMonitor.ps1') -Title "Aggiornamento $old -> $new" }
