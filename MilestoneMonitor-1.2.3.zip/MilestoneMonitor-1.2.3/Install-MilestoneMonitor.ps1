<#
.SYNOPSIS
  Installs the Milestone XProtect monitoring on a video server: Zabbix Agent 2 (active checks only, PSK),
  the local Milestone collector, the export monitor and the site data for the map.

.DESCRIPTION
  Run as Administrator, from the folder that contains this script and the files of the package:
      powershell -ExecutionPolicy Bypass -File .\Install-MilestoneMonitor.ps1

  It asks:
    - Zabbix server name (dynamic DNS)                     default controllomilestone.mysecuritycamera.org
    - site / customer code -> host name in Zabbix          e.g. ROSSI-SPA -> MS-ROSSI-SPA
    - autoregistration PSK (paste, hidden)                 from the .env of the Zabbix project (ZBX_PSK_AUTOREG)
    - Milestone read-only user and password (hidden)       saved encrypted with DPAPI on this computer
    - optional: site name, address, city, latitude, longitude (map)

  Nothing is opened inbound: the agent connects OUT to the Zabbix server on TCP 10051.
  Zabbix creates the host by itself (autoregistration, host metadata "milestone-xprotect").
  Log: C:\ProgramData\zbx-milestone\install.log (never contains passwords or keys).
#>
[CmdletBinding()]
param(
    [string] $ZabbixServer,
    [string] $SiteCode,
    [string] $MilestoneUser,
    [string] $MgmUrl,
    [string] $AgentVersion = '8.0.0',
    # update channel: stable (customers) or test (laboratory); empty = keep the current one (stable if new)
    [string] $Channel
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Security

$PKG = $PSScriptRoot
# package files extracted from a zip downloaded with a browser keep the "internet" mark: RemoteSigned would block them
Get-ChildItem $PKG -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$DATA = Join-Path $env:ProgramData 'zbx-milestone'
$AGENT_DIR = 'C:\Program Files\Zabbix Agent 2'
$PSK_IDENTITY = 'PSK-AUTOREG-MILESTONE'
$METADATA = 'milestone-xprotect windows'
$DEFAULT_SERVER = 'controllomilestone.mysecuritycamera.org'
New-Item -ItemType Directory -Force $DATA | Out-Null
$LOG = Join-Path $DATA 'install.log'

function Write-Step([string]$m, [string]$color = 'Cyan') {
    Write-Host $m -ForegroundColor $color
    Add-Content -Path $LOG -Value ("{0:s} {1}" -f (Get-Date), $m)
}
function Ask([string]$prompt, [string]$default = '') {
    $p = if ($default) { "$prompt [$default]" } else { $prompt }
    $v = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($v)) { $default } else { $v.Trim() }
}
function Ask-Secret([string]$prompt) {
    $s = Read-Host $prompt -AsSecureString
    [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
}
function Protect-Text([string]$text) {
    [Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($text), $null, 'LocalMachine')
}

# Runs a script with the same account as the agent (one-shot scheduled task) and returns its output,
# so the Milestone access is tested for real. The password is passed to Windows, not on a command line.
function Invoke-AsAgentAccount([string]$script, [string]$arguments) {
    $out = Join-Path $DATA 'test-output.txt'
    Remove-Item $out -Force -ErrorAction SilentlyContinue
    $name = 'zbx-milestone-test'
    $action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument (
        "/c powershell.exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File `"$script`" $arguments > `"$out`" 2>&1")
    try {
        if ($authMode -eq 'windows') {
            # the Task Scheduler does not resolve ".\user" (error 0x80070534): use COMPUTER\user
            Register-ScheduledTask -TaskName $name -Action $action -User (Resolve-LocalAccount $svcUser) -Password $svcPw `
                -RunLevel Highest -Force -ErrorAction Stop | Out-Null
        } else {
            Register-ScheduledTask -TaskName $name -Action $action -User 'SYSTEM' -RunLevel Highest -Force -ErrorAction Stop | Out-Null
        }
    } catch { return "ERROR: test non eseguito (attivita' di prova non creata: $($_.Exception.Message.Trim()))" }
    Start-ScheduledTask -TaskName $name
    for ($i = 0; $i -lt 120 -and (Get-ScheduledTask -TaskName $name).State -eq 'Running'; $i++) { Start-Sleep 1 }
    Start-Sleep 1
    Unregister-ScheduledTask -TaskName $name -Confirm:$false
    if (Test-Path $out) { $r = Get-Content $out -Raw; Remove-Item $out -Force; return $r.Trim() }
    'ERROR: test non eseguito'
}

# ".\user" (how services show a local account) -> "COMPUTER\user", which every Windows API accepts
function Resolve-LocalAccount([string]$account) {
    if ($account.StartsWith('.\')) { "$env:COMPUTERNAME\$($account.Substring(2))" } else { $account }
}

# Gives "Log on as a service" to an account (services.msc does it by itself, the WMI Change method does not).
function Grant-ServiceLogonRight([string]$account) {
    $name = Resolve-LocalAccount $account
    $sid = (New-Object Security.Principal.NTAccount($name)).Translate([Security.Principal.SecurityIdentifier]).Value
    $tmp = Join-Path $env:TEMP 'zbx-secpol'
    secedit /export /cfg "$tmp.inf" /areas USER_RIGHTS | Out-Null
    $line = (Get-Content "$tmp.inf") | Where-Object { $_ -like 'SeServiceLogonRight*' }
    if ($line -and $line -match [regex]::Escape("*$sid")) { Remove-Item "$tmp.*" -Force -ErrorAction SilentlyContinue; return }
    $value = if ($line) { "$line,*$sid" } else { "SeServiceLogonRight = *$sid" }
    @('[Unicode]', 'Unicode=yes', '[Version]', 'signature="$CHICAGO$"', 'Revision=1', '[Privilege Rights]', $value) |
        Set-Content "$tmp.new.inf" -Encoding Unicode
    secedit /configure /db "$tmp.sdb" /cfg "$tmp.new.inf" /areas USER_RIGHTS | Out-Null
    Remove-Item "$tmp.*" -Force -ErrorAction SilentlyContinue
}

# ---------------------------------------------------------------- checks
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Avviare come Amministratore.' }
foreach ($f in 'milestone_collect.ps1', 'milestone_export_status.ps1', 'milestone_monitor.conf', 'VERSION', 'Report-MilestoneMonitor.ps1',
           'Update-MilestoneMonitor.ps1', 'update_key.xml') {
    if (-not (Test-Path (Join-Path $PKG $f))) { throw "Manca il file $f nella cartella dell'installer." }
}
$pkgVersion = (Get-Content (Join-Path $PKG 'VERSION') -Raw).Trim()
Write-Step "Installazione monitoraggio Milestone - pacchetto $pkgVersion" 'Green'

# ---------------------------------------------------------------- questions
if (-not $ZabbixServer) { $ZabbixServer = Ask 'Nome del server Zabbix (DNS dinamico)' $DEFAULT_SERVER }
if (-not $SiteCode) { $SiteCode = Ask 'Codice cliente / sito (lettere, numeri, trattino)' $env:COMPUTERNAME }
$SiteCode = ($SiteCode.ToUpper() -replace '[^A-Z0-9_.-]', '-').Trim('-')
$hostName = "MS-$SiteCode"
Write-Step "Nome host in Zabbix: $hostName"

$psk = (Ask-Secret "PSK di registrazione ($PSK_IDENTITY), incollare e premere Invio").Trim()
if ($psk -notmatch '^[0-9a-fA-F]{64,512}$') { throw 'PSK non valida: servono almeno 64 caratteri esadecimali.' }

$defaultMgm = "http://$env:COMPUTERNAME"
if (-not $MgmUrl) { $MgmUrl = Ask 'Indirizzo del Management Server Milestone' $defaultMgm }

# API mode: REST (XProtect 2022 R1 and later) or legacy (older, e.g. 2020 R3: MilestonePSTools + Windows access)
$apiMode = 'rest'
try { $wk = Invoke-WebRequest -UseBasicParsing -Uri ($MgmUrl.TrimEnd('/') + '/api/.well-known/uris') -TimeoutSec 15 }
catch { $wk = $null }
if (-not $wk -or $wk.StatusCode -ne 200) {
    $apiMode = 'legacy'
    Write-Step 'XProtect senza API REST (versione precedente alla 2022 R1): modalita'' compatibile con MilestonePSTools' 'Yellow'
    if (-not (Get-Module -ListAvailable -Name MilestonePSTools)) {
        throw 'Serve MilestonePSTools su questo server (Install-Module MilestonePSTools), poi rilanciare l''installer.'
    }
} else { Write-Step 'XProtect con API REST: modalita'' normale' }
Write-Host ''
Write-Host 'Accesso a Milestone:' -ForegroundColor Yellow
Write-Host '  1 = Windows (consigliato): l''agent Zabbix gira come un utente Windows che e'' gia'' in un ruolo'
Write-Host '      Milestone (es. .\Administrator). La password la custodisce Windows, come per ogni servizio.'
Write-Host '      Attenzione: se la password di quell''utente cambia, va rimessa nel servizio Zabbix Agent 2.'
Write-Host '  2 = utente base XProtect con password (salvata cifrata su questo computer), agent come SYSTEM'
$authMode = if ($MilestoneUser) { 'basic' } elseif ((Ask 'Scelta' '1') -eq '2') { 'basic' } else { 'windows' }
# 1.2.3: the basic user works also in legacy mode (MilestonePSTools Connect-Vms -BasicUser), user 2026-11-23
$milestonePw = $null; $svcUser = $null; $svcPw = $null
if ($authMode -eq 'basic') {
    if (-not $MilestoneUser) { $MilestoneUser = Ask 'Utente base XProtect di sola lettura' 'zabbix-monitor' }
    $milestonePw = Ask-Secret "Password dell'utente $MilestoneUser"
} else {
    $svcUser = Ask 'Utente Windows per l''agent (deve essere in un ruolo Milestone)' '.\Administrator'
    $svcPw = Ask-Secret "Password di $svcUser (non viene salvata dall'installer)"
}

Write-Host ''
Write-Host 'NAS della rete locale (archivi, esportazioni): li trovo dai percorsi di rete di Milestone.' -ForegroundColor Yellow
$snmpCommunity = (Ask-Secret 'Community SNMP in sola lettura dei NAS QNAP (Invio per saltare)').Trim()
# SNMP port of the NAS (QNAP: Pannello di controllo > Rete e servizi file > SNMP > Numero di porta).
# Enter = automatic: 161, then 1619; the port that answers is remembered (snmp_ports.json).
$snmpPorts = @()
if ($snmpCommunity) {
    $p = Ask 'Porta SNMP dei NAS (Invio = automatica: prova 161 e 1619)'
    if ($p) {
        if ($p -notmatch '^\d{1,5}$' -or [int]$p -lt 1 -or [int]$p -gt 65535) { throw "Porta SNMP non valida: $p" }
        $snmpPorts = @([int]$p) + @(161) | Select-Object -Unique
    }
}
$nasExtra = @((Ask 'Altri NAS da controllare (IP o nomi separati da virgola, Invio per nessuno)') -split '[,; ]+' | Where-Object { $_ })
Write-Host ''
Write-Host 'Dati del sito per la mappa (Invio per saltare):' -ForegroundColor Yellow
$site = [ordered]@{
    name = Ask 'Nome del sito (es. Magazzino Rossi)'
    address = Ask 'Indirizzo'
    city = Ask 'Citta'
    lat = Ask 'Latitudine (es. 44.0631)'
    lon = Ask 'Longitudine (es. 12.4466)'
}
foreach ($k in 'lat', 'lon') { $site[$k] = $site[$k] -replace ',', '.' }

# ---------------------------------------------------------------- Milestone configuration
Write-Step "Salvo la configurazione Milestone (accesso: $authMode)"
$conf = @{ mgm_url = $MgmUrl; api = $apiMode; auth = $authMode; user = "$MilestoneUser"; mob_port = 0; nas_hosts = $nasExtra }
if ($snmpPorts.Count) { $conf.snmp_ports = @($snmpPorts) }
$conf | ConvertTo-Json | Set-Content (Join-Path $DATA 'config.json') -Encoding UTF8
Remove-Item (Join-Path $DATA 'snmp_ports.json') -Force -ErrorAction SilentlyContinue   # found again with the new settings
if ($authMode -eq 'basic') { [IO.File]::WriteAllBytes((Join-Path $DATA 'credential.bin'), (Protect-Text $milestonePw)) }
else { Remove-Item (Join-Path $DATA 'credential.bin') -Force -ErrorAction SilentlyContinue }   # nothing to keep
$milestonePw = $null
$siteOut = [ordered]@{}; foreach ($k in $site.Keys) { if ($site[$k]) { $siteOut[$k] = $site[$k] } }
# UTF-8 without BOM: read as is by the agent (milestone.site)
[IO.File]::WriteAllText((Join-Path $DATA 'site.json'), ($siteOut | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false))
if ($snmpCommunity) { [IO.File]::WriteAllBytes((Join-Path $DATA 'snmp.bin'), (Protect-Text $snmpCommunity)) }
else { Remove-Item (Join-Path $DATA 'snmp.bin') -Force -ErrorAction SilentlyContinue }
$snmpCommunity = $null
Remove-Item (Join-Path $DATA 'token.bin'), (Join-Path $DATA 'info.json') -Force -ErrorAction SilentlyContinue
icacls $DATA /inheritance:r /grant:r 'SYSTEM:(OI)(CI)F' 'Administrators:(OI)(CI)F' | Out-Null
if ($authMode -eq 'windows') { icacls $DATA /grant:r "$(Resolve-LocalAccount $svcUser):(OI)(CI)M" | Out-Null }   # agent account

# ---------------------------------------------------------------- Zabbix Agent 2
$msiName = "zabbix_agent2-$AgentVersion-windows-amd64-openssl.msi"
$msiUrl = "https://cdn.zabbix.com/zabbix/binaries/stable/$($AgentVersion.Substring(0,3))/$AgentVersion/$msiName"
$msi = Join-Path $env:TEMP $msiName
Write-Step "Scarico Zabbix Agent 2 $AgentVersion"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri $msiUrl -OutFile $msi -UseBasicParsing
Write-Step ("MSI SHA256 " + (Get-FileHash $msi -Algorithm SHA256).Hash)

# Active checks only. SERVER=127.0.0.1: passive checks only from this computer, nothing opened inbound.
$msiArgs = @('/i', "`"$msi`"", '/qn', '/norestart', '/le', "`"$DATA\agent-msi.log`"",
    'SERVER=127.0.0.1', "SERVERACTIVE=$ZabbixServer", "HOSTNAME=$hostName", "HOSTMETADATA=`"$METADATA`"",
    'TLSCONNECT=psk', 'TLSACCEPT=psk', "TLSPSKIDENTITY=$PSK_IDENTITY", "TLSPSKVALUE=$psk",
    'ENABLEPATH=1', 'LISTENPORT=10050')
# copied BEFORE the agent is installed: the MSI starts the agent at once, and keys asked before the
# configuration is in place are marked 'not supported' by Zabbix until their next check (up to 1 hour)
# ---------------------------------------------------------------- scripts and agent configuration
Write-Step 'Copio gli script di raccolta e la configurazione'
New-Item -ItemType Directory -Force "$AGENT_DIR\scripts", "$AGENT_DIR\zabbix_agent2.d" | Out-Null
Copy-Item (Join-Path $PKG 'milestone_collect.ps1'), (Join-Path $PKG 'milestone_export_status.ps1') "$AGENT_DIR\scripts\" -Force
Copy-Item (Join-Path $PKG 'milestone_monitor.conf') "$AGENT_DIR\zabbix_agent2.d\" -Force
# the agent runs the scripts with RemoteSigned (1.1.7): no "downloaded from internet" mark may stay on them
Get-ChildItem "$AGENT_DIR\scripts\*.ps1" | Unblock-File
Remove-Item "$AGENT_DIR\zabbix_agent2.d\milestone_export.conf" -Force -ErrorAction SilentlyContinue   # old name
Set-Content (Join-Path $DATA 'package_version.txt') $pkgVersion -Encoding ASCII

Write-Step 'Installo Zabbix Agent 2 (solo controlli attivi, cifratura PSK)'
$p = Start-Process msiexec.exe -ArgumentList $msiArgs -Wait -PassThru
$psk = $null
if ($p.ExitCode -notin 0, 3010) { throw "Installazione agent fallita (codice $($p.ExitCode)), vedi $DATA\agent-msi.log" }

Get-NetFirewallRule -DisplayName 'Zabbix Agent 2*' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
if ($authMode -eq 'windows') {
    Write-Step "L'agent Zabbix girera' come $svcUser"
    Grant-ServiceLogonRight $svcUser
    $svc = Get-CimInstance Win32_Service -Filter "Name='Zabbix Agent 2'"
    $r = Invoke-CimMethod -InputObject $svc -MethodName Change -Arguments @{ StartName = $svcUser; StartPassword = $svcPw }
    if ($r.ReturnValue -ne 0) { throw "Impostazione dell'account del servizio non riuscita (codice $($r.ReturnValue)): controllare utente e password." }
} else {
    $svc = Get-CimInstance Win32_Service -Filter "Name='Zabbix Agent 2'"
    Invoke-CimMethod -InputObject $svc -MethodName Change -Arguments @{ StartName = 'LocalSystem'; StartPassword = '' } | Out-Null
}
Restart-Service 'Zabbix Agent 2'

Write-Step 'Aggiornamento automatico (attivita'' pianificata giornaliera, pacchetti firmati)'
if ($Channel) { & (Join-Path $PKG 'Update-MilestoneMonitor.ps1') -Register -Channel $Channel }
else { & (Join-Path $PKG 'Update-MilestoneMonitor.ps1') -Register }

# ---------------------------------------------------------------- tests
Write-Host ''
Write-Step 'Prova della lettura Milestone...'
# run the test with the agent account (one-shot scheduled task): the Milestone access is checked for real
$test = Invoke-AsAgentAccount "$AGENT_DIR\scripts\milestone_collect.ps1" 'info'
$svcPw = $null
if ("$test" -like 'ERROR:*') {
    Write-Step "  Milestone NON letto: $test" 'Red'
    if ($authMode -eq 'windows') {
        Write-Step "  Accesso Windows: l'utente $svcUser deve essere in un ruolo Milestone (Management Client > Ruoli)." 'Red'
    } else {
        Write-Step '  Controllare indirizzo, utente e password (ruolo senza "Login authorization required").' 'Red'
    }
} else {
    $info = "$test" | ConvertFrom-Json
    Write-Step ("  OK: {0} {1}, {2} recorder, {3} telecamere" -f $info.Product.Name, $info.Product.Version,
        @($info.Srv.Rec).Count, @($info.Hw.Cam).Count) 'Green'
}
# final report: every key, the NAS, the exports and the connection to Zabbix (install-report.txt)
& (Join-Path $PKG 'Report-MilestoneMonitor.ps1') -Title "Installazione $pkgVersion"

Write-Host ''
Write-Step "Fatto. Fra qualche minuto il server compare in Zabbix come '$hostName' (gruppo Milestone XProtect)." 'Green'
Write-Step "La scheda del server e le telecamere arrivano entro circa 15-20 minuti. Log: $LOG" 'Green'
Write-Step 'Gli aggiornamenti arrivano da soli ogni notte (attivita'' MilestoneMonitor-Aggiornamento).' 'Green'
