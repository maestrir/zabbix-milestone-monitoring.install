<#
.SYNOPSIS
  Final report of the Milestone monitoring on this video server: one OK / NO line for every check.

.DESCRIPTION
  Called at the end of Install-MilestoneMonitor.ps1 and Aggiorna-MilestoneMonitor.ps1, can also be run by itself
  (PowerShell as Administrator):  powershell -ExecutionPolicy Bypass -File .\Report-MilestoneMonitor.ps1
  Every agent key is tested by running the same script the agent runs, as the user running this report
  (with the Windows access this must be the agent account, e.g. Administrator).
  Report: C:\ProgramData\zbx-milestone\install-report.txt (no passwords, no keys).
#>
[CmdletBinding()]
param([string] $Title = 'Rapporto monitoraggio Milestone')

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$DATA = Join-Path $env:ProgramData 'zbx-milestone'
$AGENT_DIR = 'C:\Program Files\Zabbix Agent 2'
$OUT = Join-Path $DATA 'install-report.txt'
$lines = New-Object System.Collections.Generic.List[string]
$counts = @{ OK = 0; NO = 0; ATT = 0 }

function Say([string]$status, [string]$text) {
    $line = "[{0}] {1}" -f $status, $text
    $color = switch ($status) { 'OK' { 'Green' } 'NO' { 'Red' } 'ATT' { 'Yellow' } default { 'Gray' } }
    Write-Host $line -ForegroundColor $color
    $lines.Add($line)
    if ($counts.ContainsKey($status)) { $counts[$status]++ }
}
function Short([string]$t, [int]$n = 250) { $t = ($t -replace '\s+', ' ').Trim(); $t.Substring(0, [Math]::Min($n, $t.Length)) }
function Run-Key([string]$script, [string]$arg, [int]$timeoutSec = 150) {
    # with a time limit (a bit more than the agent's 120 s): a slow check must not leave the installation hanging
    # (L'AQUILA 2026-11-22: retention over archives on NAS, the report never ended)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $psi = New-Object Diagnostics.ProcessStartInfo 'powershell.exe'
    $psi.Arguments = "-NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File `"$script`" $arg"
    $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $p = [Diagnostics.Process]::Start($psi)
    $so = $p.StandardOutput.ReadToEndAsync(); $se = $p.StandardError.ReadToEndAsync()
    if ($p.WaitForExit($timeoutSec * 1000)) {
        $o = $so.Result + $se.Result
    } else {
        try { $p.Kill() } catch { }
        $o = "ERROR: nessuna risposta in $timeoutSec secondi (in Zabbix questa chiave va in timeout dopo 120 s)"
    }
    @{ out = "$o".Trim(); sec = [math]::Round($sw.Elapsed.TotalSeconds, 1) }
}
function Parse($r) { if ($r.out -like '{*') { try { return ($r.out | ConvertFrom-Json) } catch { } }; $null }

Write-Host ''
Write-Host "== $Title ==" -ForegroundColor Cyan
$lines.Add("$Title - $env:COMPUTERNAME - {0:yyyy-MM-dd HH:mm}" -f (Get-Date))
$ver = if (Test-Path "$DATA\package_version.txt") { (Get-Content "$DATA\package_version.txt" -Raw).Trim() } else { '?' }
Say 'INFO' "Pacchetto installato: $ver; utente che esegue le prove: $([Security.Principal.WindowsIdentity]::GetCurrent().Name)"

# ---------------------------------------------------------------- agent
$svc = Get-CimInstance Win32_Service -Filter "Name='Zabbix Agent 2'" -ErrorAction SilentlyContinue
if (-not $svc) { Say 'NO' 'Servizio Zabbix Agent 2 non installato' }
else {
    Say $(if ($svc.State -eq 'Running') { 'OK' } else { 'NO' }) ("Servizio Zabbix Agent 2: {0}, account {1}" -f $svc.State, $svc.StartName)
}
$conf = "$AGENT_DIR\zabbix_agent2.conf"
$serverActive = ''
if (Test-Path $conf) {
    $serverActive = ((Select-String -Path $conf -Pattern '^ServerActive=(.*)$' | Select-Object -First 1).Matches.Groups[1].Value).Trim()
    $hostName = ((Select-String -Path $conf -Pattern '^Hostname=(.*)$' | Select-Object -First 1).Matches.Groups[1].Value).Trim()
    Say 'INFO' "Nome in Zabbix: $hostName; server Zabbix: $serverActive"
}
$mm = "$AGENT_DIR\zabbix_agent2.d\milestone_monitor.conf"
Say $(if (Test-Path $mm) { 'OK' } else { 'NO' }) ("Configurazione chiavi Milestone: {0}" -f $(if (Test-Path $mm) { 'presente' } else { 'MANCANTE' }))
if (Test-Path "$AGENT_DIR\zabbix_agent2.d\milestone_export.conf") { Say 'NO' 'Vecchio file milestone_export.conf presente: chiave doppia, l''agent non parte' }

# ---------------------------------------------------------------- Zabbix server
if ($serverActive) {
    $zhost = ($serverActive -split '[,;]')[0].Trim(); $zport = 10051
    if ($zhost -match '^(.*):(\d+)$') { $zhost = $Matches[1]; $zport = [int]$Matches[2] }
    $t = Test-NetConnection -ComputerName $zhost -Port $zport -WarningAction SilentlyContinue
    Say $(if ($t.TcpTestSucceeded) { 'OK' } else { 'NO' }) ("Collegamento verso Zabbix {0}:{1}{2}" -f $zhost, $zport, $(if ($t.TcpTestSucceeded) { " ($($t.RemoteAddress))" } else { ': NON raggiungibile (DNS, internet o inoltro sul router)' }))
}

# ---------------------------------------------------------------- Milestone keys
$collect = "$AGENT_DIR\scripts\milestone_collect.ps1"
$cfg = $null
if (Test-Path "$DATA\config.json") { $cfg = Get-Content "$DATA\config.json" -Raw | ConvertFrom-Json }
if ($cfg) { Say 'INFO' ("Milestone: {0}, modalita' {1}, accesso {2}" -f $cfg.mgm_url, $(if ($cfg.api) { $cfg.api } else { 'rest' }), $cfg.auth) }
if ($cfg -and $cfg.auth -eq 'windows' -and $svc) {
    # with the Windows access the Milestone checks are real only when run by the agent account
    $agentUser = "$($svc.StartName)" -replace '^\.\\', "$env:COMPUTERNAME\"
    $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    if ($agentUser -notlike $me -and $agentUser -ne 'LocalSystem') {
        Say 'ATT' ("Le prove Milestone sotto girano come {0}, ma l'agent usa {1}: per un risultato vero rilanciare come {1}" -f $me, $agentUser)
    }
}
if (-not (Test-Path $collect)) { Say 'NO' 'Script milestone_collect.ps1 mancante' }
else {
    $r = Run-Key $collect 'info'; $i = Parse $r
    if ($i) {
        $active = @($i.Hw.Cam | Where-Object { $_.enabled -and $_.hwEnabled -ne $false }).Count
        Say 'OK' ("Elenchi Milestone ({0} s): {1} {2}, {3} recorder, {4} telecamere ({5} attive)" -f $r.sec, $i.Product.Name, $i.Product.Version, @($i.Srv.Rec).Count, @($i.Hw.Cam).Count, $active)
    } else { Say 'NO' ("Elenchi Milestone ({0} s): {1}" -f $r.sec, (Short $r.out)) }

    $r = Run-Key $collect 'status'; $s = Parse $r
    if ($s) {
        $recs = ($s.rec.PSObject.Properties | ForEach-Object { $_.Value }) -join ', '
        Say $(if ($recs -match 'Connected' -and $recs -notmatch 'failed') { 'OK' } else { 'ATT' }) ("Stato ({0} s): recorder {1}; {2} telecamere, {3} in registrazione" -f $r.sec, $recs, @($s.cam).Count, @($s.cam | Where-Object { $_.Recording -eq 'true' }).Count)
    } else { Say 'NO' ("Stato ({0} s): {1}" -f $r.sec, (Short $r.out)) }

    $r = Run-Key $collect 'license'; $l = Parse $r
    if ($l) { Say $(if ($l.summary -notmatch '^n/d') { 'OK' } else { 'ATT' }) ("Licenze ({0} s): {1}" -f $r.sec, $l.summary) }
    else { Say 'NO' ("Licenze ({0} s): {1}" -f $r.sec, (Short $r.out)) }

    $r = Run-Key $collect 'retention'; $re = Parse $r
    if ($re) { Say 'OK' ("Conservazione reale: {0} telecamere con registrazioni (calcolo in background di {1} s, {2} min fa)" -f @($re.cam.PSObject.Properties).Count, $re.seconds, $re.age_min) }
    elseif ($r.out -match 'primo calcolo in corso') { Say 'ATT' "Conservazione reale: primo calcolo avviato in background, i dati arrivano in Zabbix entro un'ora" }
    else { Say 'NO' ("Conservazione reale ({0} s): {1}" -f $r.sec, (Short $r.out)) }

    $r = Run-Key $collect 'nas'; $n = Parse $r
    if ($n) {
        Say 'OK' ("NAS ({0} s): {1} NAS, {2} cartelle di rete" -f $r.sec, @($n.nas).Count, @($n.shares).Count)
        foreach ($x in @($n.nas)) {
            $snmp = switch ([int]$x.snmp) { -1 { 'SNMP non configurato' } 0 { "SNMP NON risponde ($($x.snmp_error))" } default { "SNMP OK: $($x.name), $(@($x.disks).Count) dischi, $(@($x.volumes).Count) volumi" } }
            Say $(if ($x.smb -eq 1 -and $x.snmp -ne 0) { 'OK' } else { 'ATT' }) ("  NAS {0} ({1}): condivisioni {2}; {3}" -f $x.host, $x.ip, $(if ($x.smb -eq 1) { 'raggiungibili' } else { 'NON raggiungibili' }), $snmp)
        }
        foreach ($x in @($n.shares)) {
            Say $(if ($x.ok -eq 1) { 'OK' } else { 'NO' }) ("  Cartella {0} ({1}): {2}" -f $x.path, $x.use, $(if ($x.ok -eq 1) { "{0:N0} GB liberi su {1:N0} ({2}%)" -f ($x.free / 1GB), ($x.total / 1GB), $x.pfree } else { 'NON raggiungibile' }))
        }
    } else { Say 'NO' ("NAS ({0} s): {1}" -f $r.sec, (Short $r.out)) }
}
$exp = "$AGENT_DIR\scripts\milestone_export_status.ps1"
if (Test-Path $exp) {
    $r = Run-Key $exp ''; $e = Parse $r
    if ($e) {
        $st = @{ 0 = 'nessuna esportazione trovata'; 1 = 'in corso'; 2 = 'terminata'; 3 = 'interrotta'; 4 = 'annullata' }[[int]$e.state]
        Say $(if ($e.path) { 'OK' } else { 'ATT' }) ("Esportazioni ({0} s): cartella {1}; ultima: {2} {3}" -f $r.sec, $(if ($e.path) { $e.path } else { 'non trovata' }), $st, $e.folder)
    } else { Say 'NO' ("Esportazioni ({0} s): {1}" -f $r.sec, (Short $r.out)) }
}
$task = Get-ScheduledTask -TaskName 'MilestoneMonitor-Aggiornamento' -ErrorAction SilentlyContinue
if ($task) {
    $us = $null; try { $us = Get-Content "$DATA\update_status.json" -Raw | ConvertFrom-Json } catch { }
    Say 'OK' ("Aggiornamento automatico: attivo, canale {0}, ogni giorno alle {1:HH:mm}; ultimo esito: {2} {3}" -f $us.channel,
        [datetime]$task.Triggers[0].StartBoundary, $us.result, $us.message)
} else { Say 'ATT' 'Aggiornamento automatico NON attivo (attivita'' MilestoneMonitor-Aggiornamento assente)' }
$site = "$DATA\site.json"
if (Test-Path $site) { Say 'INFO' ("Dati del sito: {0}" -f (Short (Get-Content $site -Raw))) } else { Say 'ATT' 'Dati del sito (site.json) assenti: la posizione si mette in Zabbix' }

Write-Host ''
$sum = "Riepilogo: {0} OK, {1} da controllare, {2} errori" -f $counts.OK, $counts.ATT, $counts.NO
Write-Host $sum -ForegroundColor $(if ($counts.NO) { 'Red' } elseif ($counts.ATT) { 'Yellow' } else { 'Green' })
$lines.Add($sum)
New-Item -ItemType Directory -Force $DATA | Out-Null
$lines | Set-Content -Path $OUT -Encoding UTF8
Write-Host "Rapporto salvato in: $OUT (mandalo a chi segue Zabbix, non contiene password)" -ForegroundColor Cyan
