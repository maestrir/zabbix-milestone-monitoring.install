<#
.SYNOPSIS
  Changes only how the monitoring logs in to Milestone, without reinstalling:
    1 = Windows: the Zabbix Agent 2 service runs as a Windows/domain user that is in a Milestone role
    2 = XProtect basic user with password (saved encrypted with DPAPI on this computer), agent as SYSTEM
  Optionally also changes the list of the "other NAS" to check.

.DESCRIPTION
  Run as Administrator, from the folder of the package (1.2.3 or later):
      powershell -ExecutionPolicy Bypass -File .\Cambia-AccessoMilestone.ps1

  If the package is newer than the installed one, it first updates the scripts (Aggiorna-MilestoneMonitor.ps1):
  the basic user in legacy mode (XProtect before 2022 R1, MilestonePSTools) needs collector 1.2.3.
  The new access is TESTED before anything changes; if the test fails, the old settings stay.
  Passwords are never written in clear, in a file or in the log.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Security

$PKG = $PSScriptRoot
Get-ChildItem $PKG -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$DATA = Join-Path $env:ProgramData 'zbx-milestone'
$AGENT_DIR = 'C:\Program Files\Zabbix Agent 2'
$LOG = Join-Path $DATA 'install.log'
$SERVICE = 'Zabbix Agent 2'
$CONF_FILE = Join-Path $DATA 'config.json'
$CRED_FILE = Join-Path $DATA 'credential.bin'

function Write-Step([string]$m, [string]$color = 'Cyan') {
    Write-Host $m -ForegroundColor $color
    Add-Content -Path $LOG -Value ("{0:s} {1}" -f (Get-Date), $m)
}
function Ask([string]$prompt, [string]$default = '') {
    $p = if ($default) { "$prompt [$default]" } else { $prompt }
    $v = Read-Host $p
    if ([string]::IsNullOrWhiteSpace($v)) { $default } else { $v.Trim() }
}
function Ask-Secret([string]$prompt) {
    $s = Read-Host $prompt -AsSecureString
    [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))
}
function Protect-Text([string]$text) {
    [Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($text), $null, 'LocalMachine')
}
# ".\user" (how services show a local account) -> "COMPUTER\user", which every Windows API accepts
function Resolve-LocalAccount([string]$account) {
    if ($account.StartsWith('.\')) { "$env:COMPUTERNAME\$($account.Substring(2))" } else { $account }
}
# same as the installer: "Log on as a service" (the WMI Change method does not give it)
function Grant-ServiceLogonRight([string]$account) {
    $name = Resolve-LocalAccount $account
    $sid = (New-Object Security.Principal.NTAccount($name)).Translate([Security.Principal.SecurityIdentifier]).Value
    $tmp = Join-Path $env:TEMP 'zbx-secpol'
    secedit /export /cfg "$tmp.inf" /areas USER_RIGHTS | Out-Null
    $line = (Get-Content "$tmp.inf") | Where-Object { $_ -like 'SeServiceLogonRight*' }
    if ($line -and $line -match [regex]::Escape("*$sid")) { Remove-Item "$tmp.*" -Force -ErrorAction SilentlyContinue; return }
    $value = if ($line) { "$line,*$sid" } else { "SeServiceLogonRight = *$sid" }
    @('[Unicode]', 'Unicode=yes', '[Version]', 'signature="$CHICAGO$"', 'Revision=1', '[Privilege Rights]', $value) |
        Set-Content "$tmp.new.inf" -Encoding Unicode
    secedit /configure /db "$tmp.sdb" /cfg "$tmp.new.inf" /areas USER_RIGHTS | Out-Null
    Remove-Item "$tmp.*" -Force -ErrorAction SilentlyContinue
}
# runs the collector once as the account the agent will use (one-shot scheduled task), like the installer.
# $account empty = SYSTEM (basic user access)
function Invoke-AsAccount([string]$account, [string]$password) {
    $out = Join-Path $DATA 'test-output.txt'
    Remove-Item $out -Force -ErrorAction SilentlyContinue
    $name = 'zbx-milestone-test'
    $action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument (
        "/c powershell.exe -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File `"$AGENT_DIR\scripts\milestone_collect.ps1`" info > `"$out`" 2>&1")
    try {
        if ($account) {
            Register-ScheduledTask -TaskName $name -Action $action -User (Resolve-LocalAccount $account) -Password $password `
                -RunLevel Highest -Force -ErrorAction Stop | Out-Null
        } else {
            Register-ScheduledTask -TaskName $name -Action $action -User 'SYSTEM' -RunLevel Highest -Force -ErrorAction Stop | Out-Null
        }
    } catch { return "ERROR: prova non eseguita (utente o password non accettati da Windows: $($_.Exception.Message.Trim()))" }
    Start-ScheduledTask -TaskName $name
    for ($i = 0; $i -lt 120 -and (Get-ScheduledTask -TaskName $name).State -eq 'Running'; $i++) { Start-Sleep 1 }
    Start-Sleep 1
    Unregister-ScheduledTask -TaskName $name -Confirm:$false
    if (Test-Path $out) { $r = Get-Content $out -Raw; Remove-Item $out -Force; return "$r".Trim() }
    'ERROR: prova non eseguita'
}
function Save-Config($conf) { $conf | ConvertTo-Json | Set-Content $CONF_FILE -Encoding UTF8 }
function Set-Prop($obj, [string]$name, $value) { $obj | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force }

# ---------------------------------------------------------------- checks
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Avviare come Amministratore.' }
if (-not (Test-Path $CONF_FILE)) { throw "Monitoraggio non installato: manca $CONF_FILE" }
$svc = Get-CimInstance Win32_Service -Filter "Name='$SERVICE'"
if (-not $svc) { throw "Servizio $SERVICE non trovato." }

# scripts of this package first, if newer: the new access may need them
$pkgVersion = if (Test-Path (Join-Path $PKG 'VERSION')) { (Get-Content (Join-Path $PKG 'VERSION') -Raw).Trim() } else { '' }
$installed = if (Test-Path "$DATA\package_version.txt") { (Get-Content "$DATA\package_version.txt" -Raw).Trim() } else { '0.0' }
if ($pkgVersion -and ([version]$pkgVersion -gt [version]$installed)) {
    Write-Step "Aggiorno prima gli script: $installed -> $pkgVersion" 'Green'
    & (Join-Path $PKG 'Aggiorna-MilestoneMonitor.ps1') -Auto
}

$conf = Get-Content $CONF_FILE -Raw | ConvertFrom-Json
$oldConfText = Get-Content $CONF_FILE -Raw
$oldCred = if (Test-Path $CRED_FILE) { [IO.File]::ReadAllBytes($CRED_FILE) } else { $null }
$now = if ($conf.auth -eq 'basic') { "utente base XProtect $($conf.user), agent come SYSTEM" } else { "Windows, agent come $($svc.StartName)" }
Write-Step "Cambio dell'accesso a Milestone (ora: $now; modalita' $($conf.api))" 'Green'

# ---------------------------------------------------------------- questions
Write-Host ''
Write-Host 'Accesso a Milestone:' -ForegroundColor Yellow
Write-Host '  1 = Windows: l''agent Zabbix gira come un utente Windows o di dominio che e'' in un ruolo Milestone'
Write-Host '  2 = utente base XProtect con password (salvata cifrata su questo computer), agent come SYSTEM'
$mode = if ((Ask 'Scelta' '2') -eq '1') { 'windows' } else { 'basic' }
$account = $null; $password = $null; $basicUser = ''
if ($mode -eq 'windows') {
    $account = Ask 'Utente Windows per l''agent (per il dominio: DOMINIO\utente)'
    if (-not $account) { throw 'Nessun utente indicato: niente cambiato.' }
    if ($account -notmatch '\\' -and $account -notmatch '@') { $account = ".\$account" }
    try { $null = (New-Object Security.Principal.NTAccount((Resolve-LocalAccount $account))).Translate([Security.Principal.SecurityIdentifier]) }
    catch { throw "Utente $account non trovato da Windows." }
    $password = Ask-Secret "Password di $account (non viene salvata)"
} else {
    $default = if ($conf.auth -eq 'basic') { "$($conf.user)" } else { '' }
    $basicUser = Ask 'Utente base XProtect' $default
    if (-not $basicUser) { throw 'Nessun utente indicato: niente cambiato.' }
    $password = Ask-Secret "Password dell'utente $basicUser"
}
$oldNas = @($conf.nas_hosts | Where-Object { $_ })
Write-Host ''
Write-Host ("Altri NAS da controllare, oggi: " + $(if ($oldNas.Count) { $oldNas -join ',' } else { 'nessuno' }))
$nasAnswer = Ask 'Nuovo elenco (IP separati da virgola), "-" per nessuno, Invio per non cambiare'

# ---------------------------------------------------------------- new settings, then test
Set-Prop $conf 'auth' $mode
Set-Prop $conf 'user' $basicUser
if ($nasAnswer) {
    $nas = if ($nasAnswer -eq '-') { @() } else { @($nasAnswer -split '[,; ]+' | Where-Object { $_ }) }
    Set-Prop $conf 'nas_hosts' $nas
}
Save-Config $conf
if ($mode -eq 'basic') { [IO.File]::WriteAllBytes($CRED_FILE, (Protect-Text $password)) }
else { icacls $DATA /grant:r "$(Resolve-LocalAccount $account):(OI)(CI)M" | Out-Null }
Remove-Item (Join-Path $DATA 'token.bin') -Force -ErrorAction SilentlyContinue     # tokens of the old access

$who = if ($mode -eq 'basic') { "utente base $basicUser (come SYSTEM)" } else { $account }
Write-Step "Prova della lettura Milestone con $who..."
$test = if ($mode -eq 'basic') { Invoke-AsAccount '' '' } else { Invoke-AsAccount $account $password }
if ("$test" -like 'ERROR:*' -or "$test" -notlike '{*') {
    # back to the old settings: nothing changes for the agent
    [IO.File]::WriteAllText($CONF_FILE, $oldConfText)
    if ($oldCred) { [IO.File]::WriteAllBytes($CRED_FILE, $oldCred) } else { Remove-Item $CRED_FILE -Force -ErrorAction SilentlyContinue }
    Remove-Item (Join-Path $DATA 'token.bin') -Force -ErrorAction SilentlyContinue
    $password = $null
    $short = "$test"; if ($short.Length -gt 400) { $short = $short.Substring(0, 400) }
    Write-Step "  Milestone NON letto: $short" 'Red'
    Write-Step '  Niente cambiato: rimesse le impostazioni di prima.' 'Red'
    if ("$test" -like '*VMO61008*') { Write-Step '  Utente senza permessi: va messo in un ruolo Milestone (Management Client > Sicurezza > Ruoli).' 'Red' }
    if ("$test" -like '*MilestonePSTools*') { Write-Step '  MilestonePSTools non visibile per questo utente: Install-Module MilestonePSTools -Scope AllUsers' 'Red' }
    if ($mode -eq 'basic') { Write-Step '  Utente base: controllare utente e password, e che il ruolo non abbia "Login authorization required".' 'Red' }
    exit 1
}
$info = "$test" | ConvertFrom-Json
Write-Step ("  OK: {0} {1}, {2} recorder, {3} telecamere" -f $info.Product.Name, $info.Product.Version,
    @($info.Srv.Rec).Count, @($info.Hw.Cam).Count) 'Green'

# ---------------------------------------------------------------- agent account
if ($mode -eq 'basic') {
    $r = Invoke-CimMethod -InputObject $svc -MethodName Change -Arguments @{ StartName = 'LocalSystem'; StartPassword = '' }
    $runAs = 'SYSTEM'
} else {
    Remove-Item $CRED_FILE -Force -ErrorAction SilentlyContinue
    Grant-ServiceLogonRight $account
    $r = Invoke-CimMethod -InputObject $svc -MethodName Change -Arguments @{ StartName = $account; StartPassword = $password }
    $runAs = $account
}
$password = $null
if ($r.ReturnValue -ne 0) { throw "Impostazione dell'account del servizio non riuscita (codice $($r.ReturnValue))." }
Restart-Service $SERVICE
Write-Step "Fatto: accesso $mode, l'agent Zabbix gira come $runAs" 'Green'
if ($nasAnswer) { Write-Step ("Altri NAS: " + $(if (@($conf.nas_hosts).Count) { @($conf.nas_hosts) -join ',' } else { 'nessuno' })) }

$report = Join-Path $PKG 'Report-MilestoneMonitor.ps1'
if (Test-Path $report) { & $report -Title "Cambio accesso Milestone ($mode)" }
Write-Host ''
Write-Host 'I dati Milestone arrivano in Zabbix entro circa 15 minuti.'
