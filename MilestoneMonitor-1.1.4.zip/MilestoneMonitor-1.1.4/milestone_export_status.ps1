<#
  milestone_export_status.ps1 - state of the last video export made with the XProtect Smart Client on this server.

  The Smart Client writes no log for exports, so the state is read from the files:
    - the export folder comes from the Smart Client user settings (ExportPath in UserSettings*.xml),
      for every Windows user, so it is found even when the operator changes it;
    - the newest sub-folder of that path is the last export;
    - XProtect format: the project file (Client Files\*.scp) and the player (autorun.inf) are written LAST,
      so their presence means "finished";
    - other formats (MKV, AVI, MP4...): finished when nothing has been written for 2 minutes.

  Output (one line of JSON), read by the Zabbix agent key milestone.export.status:
    state   0 = no export found, 1 = running, 2 = finished, 3 = stopped without finishing,
            4 = cancelled (an export seen running has disappeared: the Smart Client deletes the folder on cancel;
                reported for $CANCEL_SHOW seconds, remembered in $STATE_FILE)
    folder, path, format, started (unix time), last_write (unix time), idle (s), size (bytes), files,
    recent (bytes written in the last 60 s), client (0/1)

  Install: C:\Program Files\Zabbix Agent 2\scripts\  +  zabbix_agent2.d\milestone_export.conf (UserParameter).
#>
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$RUNNING_GRACE = 300   # seconds without writes before an unfinished XProtect export counts as stopped
$MEDIA_IDLE = 120      # seconds without writes after which a media-format export counts as finished
$CANCEL_SHOW = 600     # seconds a cancelled export stays reported as state 4
$STATE_FILE = Join-Path $env:ProgramData 'zbx-milestone\export_state.json'

function To-Unix([datetime]$t) { [int64]([DateTimeOffset]$t.ToUniversalTime()).ToUnixTimeSeconds() }

# A drive letter mapped by the operator (e.g. X: -> \\nas\share) does not exist for the agent service:
# translate it into the network path, from the persistent mappings of the users (HKCU / HKU \<SID>\Network\<letter>).
function Resolve-MappedPath([string]$path) {
    if (-not $path -or (Test-Path -LiteralPath $path)) { return $path }
    if ($path -notmatch '^([A-Za-z]):(.*)$') { return $path }
    $letter = $Matches[1].ToUpper(); $rest = $Matches[2]
    $keys = @("HKCU:\Network\$letter") + @(Get-ChildItem 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue |
            ForEach-Object { "Registry::$($_.Name)\Network\$letter" })
    foreach ($k in $keys) {
        $remote = (Get-ItemProperty -Path $k -Name RemotePath -ErrorAction SilentlyContinue).RemotePath
        if ($remote) { return ($remote.TrimEnd('\') + $rest) }
    }
    $path
}

# 1. export paths from the Smart Client settings of every user
$paths = @()
Get-ChildItem 'C:\Users\*\AppData\Roaming\Milestone\Smart Client\UserSettings*.xml' -Force | ForEach-Object {
    $m = Select-String -Path $_.FullName -Pattern 'ExportPath="([^"]+)"' | Select-Object -First 1
    if ($m) { $paths += Resolve-MappedPath $m.Matches[0].Groups[1].Value }
}
$paths = $paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Sort-Object -Unique

# 2. newest export folder among all paths
$last = $paths | ForEach-Object { Get-ChildItem -LiteralPath $_ -Directory -Force } |
        Sort-Object CreationTime -Descending | Select-Object -First 1

$client = [int][bool](Get-Process -Name 'Client' -ErrorAction SilentlyContinue)
$result = [ordered]@{ state = 0; folder = ''; path = ($paths -join '; '); format = ''; started = 0;
                      last_write = 0; idle = 0; size = 0; files = 0; recent = 0; client = $client }

if ($last) {
    $files = @(Get-ChildItem -LiteralPath $last.FullName -Recurse -File -Force)
    $lastWrite = ($files | Measure-Object -Property LastWriteTime -Maximum).Maximum
    if (-not $lastWrite) { $lastWrite = $last.CreationTime }
    $idle = [int]((Get-Date) - $lastWrite).TotalSeconds
    $clientFiles = Join-Path $last.FullName 'Client Files'
    $isXProtect = Test-Path -LiteralPath $clientFiles
    if ($isXProtect) {
        $done = (Test-Path -LiteralPath (Join-Path $last.FullName 'autorun.inf')) -or
                [bool](Get-ChildItem -LiteralPath $clientFiles -Filter '*.scp' -File -Force)
        if ($done) { $state = 2 }
        elseif ($client -and $idle -lt $RUNNING_GRACE) { $state = 1 }
        else { $state = 3 }
    } else {
        $state = if ($idle -ge $MEDIA_IDLE) { 2 } else { 1 }
    }
    $result.state = $state
    $result.folder = $last.Name
    $result.path = Split-Path $last.FullName -Parent
    $result.format = if ($isXProtect) { 'XProtect' } else { 'Media' }
    $result.started = To-Unix $last.CreationTime
    $result.last_write = To-Unix $lastWrite
    $result.idle = $idle
    $result.size = [int64](($files | Measure-Object -Property Length -Sum).Sum)
    $result.files = $files.Count
    # bytes of the files written in the last minute (stateless: no false jumps when the last export changes)
    $minuteAgo = (Get-Date).AddSeconds(-60)
    $result.recent = [int64](($files | Where-Object { $_.LastWriteTime -gt $minuteAgo } |
                             Measure-Object -Property Length -Sum).Sum)
}

# 3. cancelled exports: remember the folder while it runs; if it disappears, it was cancelled
$saved = $null
if (Test-Path $STATE_FILE) { $saved = Get-Content $STATE_FILE -Raw | ConvertFrom-Json }
$now = To-Unix (Get-Date)
$running = if ($saved) { $saved.running } else { '' }
$cancelled = if ($saved) { $saved.cancelled } else { '' }
$cancelledAt = if ($saved) { [int64]$saved.cancelled_at } else { 0 }

if ($result.state -eq 1) {
    $running = Join-Path $result.path $result.folder
} elseif ($running -and -not (Test-Path -LiteralPath $running)) {
    $cancelled = Split-Path $running -Leaf
    $cancelledAt = $now
    $running = ''
} else {
    $running = ''
}
if ($cancelled -and ($now - $cancelledAt) -lt $CANCEL_SHOW -and $result.started -lt $cancelledAt) {
    $result.state = 4
    $result.folder = $cancelled
    $result.recent = 0
} elseif (($now - $cancelledAt) -ge $CANCEL_SHOW) {
    $cancelled = ''
}
New-Item -ItemType Directory -Force (Split-Path $STATE_FILE) | Out-Null
[ordered]@{ running = $running; cancelled = $cancelled; cancelled_at = $cancelledAt } |
    ConvertTo-Json -Compress | Set-Content -Path $STATE_FILE -Encoding UTF8

$result | ConvertTo-Json -Compress
